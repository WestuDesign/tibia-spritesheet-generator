bl_info = {
    "name": "Tibia Spritesheet Generator 3x4",
    "author": "Codex for TibiaDevs workflow",
    "version": (1, 4, 0),
    "blender": (4, 2, 0),
    "location": "3D View > Sidebar > Tibia 3x4",
    "description": "Renders 3 frames x 4 directions in multiple pixel-art styles and masks",
    "category": "Render",
}

from array import array
from contextlib import contextmanager
from math import cos, radians, sin
import json
import os
import shutil
import tempfile

import bpy
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import Operator, Panel, PropertyGroup
from mathutils import Matrix, Vector


ADDON_PREFIX = "TIBIA3X4_"
I18N_CONTEXT = "Tibia Spritesheet Generator"


def _iface(message):
    return bpy.app.translations.pgettext_iface(message, I18N_CONTEXT)


def _tip(message):
    return bpy.app.translations.pgettext_tip(message, I18N_CONTEXT)


def _rpt(message):
    return bpy.app.translations.pgettext_rpt(message, I18N_CONTEXT)


RENDERABLE_TYPES = {
    "MESH",
    "CURVE",
    "SURFACE",
    "META",
    "FONT",
    "VOLUME",
    "CURVES",
    "POINTCLOUD",
    "GPENCIL",
    "GREASEPENCIL",
}
CONTROL_TYPES = {"EMPTY", "ARMATURE", "LATTICE"}
FRONT_AXIS_ANGLE = {
    "NEG_Y": radians(-90.0),
    "POS_X": radians(0.0),
    "POS_Y": radians(90.0),
    "NEG_X": radians(180.0),
}


class TibiaGeneratorError(RuntimeError):
    pass


def _safe_name(name):
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in name)


def _descendants(obj):
    result = set()
    stack = list(obj.children)
    while stack:
        child = stack.pop()
        if child in result:
            continue
        result.add(child)
        stack.extend(child.children)
    return result


def _modifier_targets(obj):
    for modifier in getattr(obj, "modifiers", ()):  # modifiers are not present on every object type
        for attr in ("object", "target", "origin", "mirror_object", "offset_object"):
            target = getattr(modifier, attr, None)
            if isinstance(target, bpy.types.Object):
                yield target


def _constraint_targets(obj):
    for constraint in getattr(obj, "constraints", ()):
        target = getattr(constraint, "target", None)
        if isinstance(target, bpy.types.Object):
            yield target
    if obj.type == "ARMATURE" and getattr(obj, "pose", None):
        for bone in obj.pose.bones:
            for constraint in bone.constraints:
                target = getattr(constraint, "target", None)
                if isinstance(target, bpy.types.Object):
                    yield target


def _driver_targets(obj):
    animation_data = getattr(obj, "animation_data", None)
    if animation_data is None:
        return
    for driver_curve in animation_data.drivers:
        for variable in driver_curve.driver.variables:
            for target in variable.targets:
                target_id = getattr(target, "id", None)
                if isinstance(target_id, bpy.types.Object):
                    yield target_id


def _collection_render_objects(collection):
    result = set()

    def visit(current, hidden_parent=False):
        hidden = hidden_parent or current.hide_render
        if hidden:
            return
        result.update(current.objects)
        for child in current.children:
            visit(child, hidden)

    visit(collection)
    return result


def _object_has_renderable_collection_path(root_collection, obj, hidden_parent=False):
    hidden = hidden_parent or root_collection.hide_render
    if not hidden and root_collection.objects.get(obj.name) is obj:
        return True
    for child in root_collection.children:
        if _object_has_renderable_collection_path(child, obj, hidden):
            return True
    return False


def _collect_source_objects(context, settings):
    if settings.source_mode == "COLLECTION":
        collection = settings.target_collection
        if collection is None:
            raise TibiaGeneratorError("Select a collection containing the model.")
        objects = _collection_render_objects(collection)
    else:
        seeds = [
            obj
            for obj in context.selected_objects
            if obj.type not in {"CAMERA", "LIGHT", "SPEAKER", "LIGHT_PROBE"}
        ]
        if not seeds:
            raise TibiaGeneratorError("Select the model or choose a collection.")
        objects = set(seeds)
        if settings.include_children:
            for obj in seeds:
                objects.update(_descendants(obj))

    objects = {
        obj
        for obj in objects
        if obj.type not in {"CAMERA", "LIGHT", "SPEAKER", "LIGHT_PROBE"}
        and not obj.name.startswith(ADDON_PREFIX)
    }

    # Add non-rendering dependencies that commonly drive rigs and modifiers.
    queue = list(objects)
    visited = set(objects)
    while queue:
        obj = queue.pop()
        candidates = []
        if obj.parent is not None:
            candidates.append(obj.parent)
        armature = obj.find_armature() if hasattr(obj, "find_armature") else None
        if armature is not None:
            candidates.append(armature)
        candidates.extend(_modifier_targets(obj))
        candidates.extend(_constraint_targets(obj))
        candidates.extend(_driver_targets(obj))

        for dependency in candidates:
            safe_control = dependency.type in CONTROL_TYPES
            hidden_renderable_control = (
                dependency.type in RENDERABLE_TYPES and dependency.hide_render
            )
            if not (safe_control or hidden_renderable_control):
                continue
            if dependency in visited:
                continue
            visited.add(dependency)
            objects.add(dependency)
            queue.append(dependency)

    renderables = {
        obj for obj in objects if obj.type in RENDERABLE_TYPES and not obj.hide_render
    }
    if not renderables:
        raise TibiaGeneratorError(
            "The source contains no visible geometry. Check the collection and Hide in Render."
        )
    return objects, renderables


def _rotation_about(pivot, angle):
    return (
        Matrix.Translation(pivot)
        @ Matrix.Rotation(angle, 4, "Z")
        @ Matrix.Translation(-pivot)
    )


def _oblique_matrix(base_z, shear_x, shear_y, z_scale):
    # Matches the reference file's lattice as an affine transform:
    # x += -0.6 * height, y += 0.6 * height, z *= 0.8 around the feet plane.
    transform = Matrix.Identity(4)
    transform[0][2] = shear_x
    transform[1][2] = shear_y
    transform[2][2] = z_scale
    return (
        Matrix.Translation(Vector((0.0, 0.0, base_z)))
        @ transform
        @ Matrix.Translation(Vector((0.0, 0.0, -base_z)))
    )


def _direction_rows(settings):
    if settings.row_order == "S_E_N_W":
        return (
            ("S", radians(0.0)),
            ("E", radians(90.0)),
            ("N", radians(180.0)),
            ("W", radians(-90.0)),
        )
    return (
        ("S", radians(0.0)),
        ("W", radians(-90.0)),
        ("N", radians(180.0)),
        ("E", radians(90.0)),
    )


def _base_facing_angle(settings):
    front = FRONT_AXIS_ANGLE[settings.front_axis]
    if settings.projection_mode == "OBLIQUE":
        target_angle = radians(-90.0)  # screen bottom with a top-down camera
    else:
        target_angle = settings.camera_azimuth
    return target_angle - front + settings.rotation_offset


@contextmanager
def _scene_override(context, scene):
    with context.temp_override(scene=scene, view_layer=scene.view_layers[0]):
        yield


def _world_corners(context, scene):
    depsgraph = context.evaluated_depsgraph_get()
    depsgraph.update()

    for instance in depsgraph.object_instances:
        obj = instance.object
        original = getattr(obj, "original", obj)
        if obj.type not in RENDERABLE_TYPES or getattr(original, "hide_render", False):
            continue

        try:
            bounds = obj.bound_box
        except (AttributeError, RuntimeError):
            continue
        if not bounds:
            continue
        if all(all(abs(float(value) + 1.0) < 1.0e-8 for value in corner) for corner in bounds):
            continue

        matrix = instance.matrix_world.copy()
        for corner in bounds:
            yield matrix @ Vector(corner)


def _points_for_frames(context, scene, instancer, frames, matrices):
    points = []
    with _scene_override(context, scene):
        for frame in frames:
            scene.frame_set(frame)
            for matrix in matrices:
                instancer.matrix_basis = matrix
                context.view_layer.update()
                points.extend(_world_corners(context, scene))
    return points


def _bounds(points):
    if not points:
        raise TibiaGeneratorError(
            "Could not calculate the model bounds. Try Collection source mode."
        )
    minimum = Vector(tuple(min(point[index] for point in points) for index in range(3)))
    maximum = Vector(tuple(max(point[index] for point in points) for index in range(3)))
    return minimum, maximum


def _place_camera(camera, settings, world_min, world_max):
    center = (world_min + world_max) * 0.5
    radius = max((world_max - world_min).length * 0.5, 0.5)
    distance = max(radius * 4.0, 10.0)

    camera.data.type = "ORTHO"
    camera.data.lens = 50.0
    camera.data.clip_start = max(0.001, distance / 1000.0)
    camera.data.clip_end = max(1000.0, distance * 10.0)
    camera.data.shift_x = 0.0
    camera.data.shift_y = settings.vertical_shift

    if settings.projection_mode == "OBLIQUE":
        camera.location = Vector((center.x, center.y, world_max.z + distance))
        camera.rotation_euler = (0.0, 0.0, 0.0)
    else:
        azimuth = settings.camera_azimuth
        elevation = settings.camera_elevation
        direction = Vector(
            (
                cos(elevation) * cos(azimuth),
                cos(elevation) * sin(azimuth),
                sin(elevation),
            )
        )
        camera.location = center + direction * distance
        camera.rotation_euler = (center - camera.location).to_track_quat("-Z", "Y").to_euler()


def _fit_camera(camera, scene, points, settings):
    inverse = camera.matrix_world.inverted_safe()
    projected = [inverse @ point for point in points]
    min_x = min(point.x for point in projected)
    max_x = max(point.x for point in projected)
    min_y = min(point.y for point in projected)
    max_y = max(point.y for point in projected)

    center_x = (min_x + max_x) * 0.5
    center_y = (min_y + max_y) * 0.5
    camera.location += camera.matrix_world.to_3x3() @ Vector((center_x, center_y, 0.0))

    width = max(max_x - min_x, 1.0e-4)
    height = max(max_y - min_y, 1.0e-4)
    aspect = (
        scene.render.resolution_x
        * scene.render.pixel_aspect_x
        / max(scene.render.resolution_y * scene.render.pixel_aspect_y, 1.0)
    )
    inner_x = max(0.05, 1.0 - (2.0 * settings.padding / settings.cell_width))
    inner_y = max(0.05, 1.0 - (2.0 * settings.padding / settings.cell_height))
    camera.data.ortho_scale = (
        max(height / inner_y, width / max(aspect * inner_x, 1.0e-5)) * 1.002
    )


def _copy_light(source, temp_scene, created_objects, created_data):
    copied_data = source.data.copy()
    copied = source.copy()
    copied.data = copied_data
    copied.animation_data_clear()
    copied.matrix_world = source.matrix_world.copy()
    temp_scene.collection.objects.link(copied)
    created_objects.append(copied)
    created_data.append(copied_data)


def _create_default_lighting(temp_scene, created_objects, created_data):
    key_data = bpy.data.lights.new(ADDON_PREFIX + "Key", "SUN")
    key_data.energy = 3.0
    key_data.angle = radians(18.0)
    key = bpy.data.objects.new(ADDON_PREFIX + "Key", key_data)
    key.rotation_euler = (radians(28.0), radians(-18.0), radians(-35.0))
    temp_scene.collection.objects.link(key)
    created_objects.append(key)
    created_data.append(key_data)

    fill_data = bpy.data.lights.new(ADDON_PREFIX + "Fill", "SUN")
    fill_data.energy = 0.75
    fill_data.angle = radians(35.0)
    fill = bpy.data.objects.new(ADDON_PREFIX + "Fill", fill_data)
    fill.rotation_euler = (radians(55.0), radians(20.0), radians(145.0))
    temp_scene.collection.objects.link(fill)
    created_objects.append(fill)
    created_data.append(fill_data)


def _create_tibiadevs_lighting(
    temp_scene, world_min, world_max, created_objects, created_data
):
    """Build the SUN + SPOT rig stored in the original TibiaDevs template.

    The source Spot was authored for one fixed model scale.  Its placement and
    power are normalized to the current bounds so imported assets receive the
    same directional contrast after automatic camera fitting.
    """
    center = (world_min + world_max) * 0.5
    dimensions = world_max - world_min
    extent = max(float(dimensions.x), float(dimensions.y), float(dimensions.z), 1.0)

    world = bpy.data.worlds.new(ADDON_PREFIX + "TibiaDevsWorld")
    world.use_nodes = False
    world.color = (0.050876, 0.050876, 0.050876)
    temp_scene.world = world
    created_data.append(world)

    sun_data = bpy.data.lights.new(ADDON_PREFIX + "TibiaDevsSun", "SUN")
    sun_data.energy = 5.0
    sun_data.angle = radians(112.6)
    sun = bpy.data.objects.new(ADDON_PREFIX + "TibiaDevsSun", sun_data)
    sun.rotation_euler = (0.0, 0.0, 0.0)
    temp_scene.collection.objects.link(sun)
    created_objects.append(sun)
    created_data.append(sun_data)

    spot_data = bpy.data.lights.new(ADDON_PREFIX + "TibiaDevsSpot", "SPOT")
    normalized_scale = extent / 7.7
    spot_data.energy = max(10.0, min(50000.0, 600.0 * normalized_scale * normalized_scale))
    spot_data.spot_size = radians(56.7)
    spot_data.spot_blend = 0.15
    spot_data.shadow_soft_size = 0.0
    if hasattr(spot_data, "specular_factor"):
        spot_data.specular_factor = 0.0
    spot = bpy.data.objects.new(ADDON_PREFIX + "TibiaDevsSpot", spot_data)
    spot.location = center + Vector((-0.65 * extent, -0.38 * extent, 0.95 * extent))
    target = center + Vector((0.0, 0.0, 0.10 * extent))
    spot.rotation_euler = (target - spot.location).to_track_quat("-Z", "Y").to_euler()
    temp_scene.collection.objects.link(spot)
    created_objects.append(spot)
    created_data.append(spot_data)


def _set_if_present(owner, name, value):
    if hasattr(owner, name):
        setattr(owner, name, value)


def _clear_linestyle_modifiers(style):
    for collection_name in (
        "geometry_modifiers",
        "color_modifiers",
        "alpha_modifiers",
        "thickness_modifiers",
    ):
        collection = getattr(style, collection_name)
        for modifier in list(collection):
            collection.remove(modifier)


def _primary_lineset(view_layer, name):
    freestyle = view_layer.freestyle_settings
    freestyle.mode = "EDITOR"
    freestyle.crease_angle = radians(134.43)
    linesets = freestyle.linesets
    lineset = linesets[0] if len(linesets) else linesets.new(name)
    lineset.name = name
    lineset.show_render = True
    for extra in list(linesets)[1:]:
        extra.show_render = False
    return lineset


def _configure_lineset_selection(lineset, selected):
    selected = set(selected)
    lineset.select_by_visibility = True
    lineset.visibility = "VISIBLE"
    lineset.select_by_edge_types = True
    lineset.edge_type_combination = "OR"
    lineset.select_by_face_marks = False
    lineset.select_by_collection = False
    lineset.select_by_image_border = True
    for suffix in (
        "silhouette",
        "border",
        "crease",
        "ridge_valley",
        "suggestive_contour",
        "material_boundary",
        "contour",
        "external_contour",
        "edge_mark",
    ):
        _set_if_present(lineset, f"select_{suffix}", suffix in selected)
        _set_if_present(lineset, f"exclude_{suffix}", False)


def _configure_tibiadevs_linestyle(
    style,
    name,
    color,
    thickness,
    caps,
    sampling,
    material_color=False,
):
    style.name = name
    style.color = color
    style.alpha = 1.0
    style.thickness = thickness
    style.thickness_position = "OUTSIDE"
    style.caps = caps
    style.use_chaining = True
    style.chaining = "PLAIN"
    style.use_same_object = True
    _clear_linestyle_modifiers(style)

    geometry = style.geometry_modifiers.new("Sampling", "SAMPLING")
    geometry.sampling = sampling
    if material_color:
        modifier = style.color_modifiers.new("Material", "MATERIAL")
        modifier.material_attribute = "DIFF"
        modifier.blend = "COLOR"
        modifier.influence = 1.0
        modifier.use_ramp = False


def _configure_tibiadevs_dual_outline(scene, settings, render_scale):
    scene.render.use_freestyle = True
    outline = scene.view_layers[0]
    outline.name = "TIBIA Outline"
    outline.use = True
    outline.use_freestyle = True

    drawing = scene.view_layers.get("TIBIA Drawing")
    if drawing is None:
        drawing = scene.view_layers.new("TIBIA Drawing")
    drawing.use = True
    drawing.use_freestyle = True
    for layer in scene.view_layers:
        layer.use = layer in {outline, drawing}

    outline_lineset = _primary_lineset(outline, "Tibia Outline")
    drawing_lineset = _primary_lineset(drawing, "Tibia Drawing")
    if outline_lineset.linestyle == drawing_lineset.linestyle:
        drawing_lineset.linestyle = drawing_lineset.linestyle.copy()

    sampling = max(1.0, 1.25 * render_scale)
    _configure_lineset_selection(
        outline_lineset, {"contour", "external_contour"}
    )
    _configure_tibiadevs_linestyle(
        outline_lineset.linestyle,
        "Tibia Outline",
        settings.outline_color,
        max(1.0, settings.outline_thickness * render_scale),
        "ROUND",
        sampling,
    )

    # The source file used a strict AND rule that produces no strokes on many
    # imported GLB/FBX assets.  OR keeps the same edge families usable without
    # requiring hand-authored Freestyle edge marks.
    _configure_lineset_selection(
        drawing_lineset, {"silhouette", "contour", "edge_mark"}
    )
    _configure_tibiadevs_linestyle(
        drawing_lineset.linestyle,
        "Tibia Drawing",
        (0.019607, 0.019607, 0.019607),
        max(2.0, settings.outline_thickness * render_scale * 2.0),
        "BUTT",
        sampling,
        material_color=True,
    )

    scene.use_nodes = True
    tree = scene.node_tree
    tree.nodes.clear()
    outline_node = tree.nodes.new("CompositorNodeRLayers")
    outline_node.scene = scene
    outline_node.layer = outline.name
    drawing_node = tree.nodes.new("CompositorNodeRLayers")
    drawing_node.scene = scene
    drawing_node.layer = drawing.name
    mix = tree.nodes.new("CompositorNodeMixRGB")
    mix.blend_type = "MIX"
    mix.inputs[0].default_value = 1.0
    mix.use_alpha = True
    composite = tree.nodes.new("CompositorNodeComposite")
    # Socket indices are stable across Blender UI languages; localized socket
    # names such as "Image" are not safe identifiers.
    tree.links.new(outline_node.outputs[0], mix.inputs[1])
    tree.links.new(drawing_node.outputs[0], mix.inputs[2])
    tree.links.new(mix.outputs[0], composite.inputs[0])


def _configure_outline(
    scene, settings, enabled=None, mode="STANDARD", render_scale=1.0
):
    if enabled is None:
        enabled = settings.use_outline
    if mode == "TIBIA_DUAL" and enabled:
        _configure_tibiadevs_dual_outline(scene, settings, render_scale)
        return

    scene.use_nodes = False
    scene.render.use_freestyle = enabled
    view_layer = scene.view_layers[0]
    view_layer.use_freestyle = enabled
    if not enabled:
        return

    linesets = view_layer.freestyle_settings.linesets
    if len(linesets) == 0:
        lineset = linesets.new("Tibia Outline")
    else:
        lineset = linesets[0]
        lineset.name = "Tibia Outline"

    if mode == "TIBIA_ORIGINAL":
        _configure_lineset_selection(lineset, {"contour", "external_contour"})
    else:
        _configure_lineset_selection(
            lineset, {"silhouette", "border", "contour", "external_contour"}
        )

    style = lineset.linestyle
    style.color = settings.outline_color
    style.alpha = 1.0
    style.thickness = settings.outline_thickness * (
        render_scale if mode == "TIBIA_ORIGINAL" else 1.0
    )
    style.caps = "ROUND"
    style.use_chaining = True
    if mode == "TIBIA_ORIGINAL":
        style.thickness_position = "OUTSIDE"
        _clear_linestyle_modifiers(style)
        sampling = style.geometry_modifiers.new("Sampling", "SAMPLING")
        sampling.sampling = max(1.0, 1.25 * render_scale)


def _copy_color_management(source, target):
    target.display_settings.display_device = source.display_settings.display_device
    target.view_settings.view_transform = source.view_settings.view_transform
    target.view_settings.look = source.view_settings.look
    target.view_settings.exposure = source.view_settings.exposure
    target.view_settings.gamma = source.view_settings.gamma
    target.view_settings.use_curve_mapping = source.view_settings.use_curve_mapping
    target.sequencer_colorspace_settings.name = source.sequencer_colorspace_settings.name


def _copy_simple_rna_settings(source, target):
    for prop in source.bl_rna.properties:
        if prop.identifier == "rna_type" or prop.is_readonly:
            continue
        if prop.type in {"POINTER", "COLLECTION"}:
            continue
        try:
            setattr(target, prop.identifier, getattr(source, prop.identifier))
        except (AttributeError, TypeError, ValueError):
            continue


def _copy_timing_and_engine(source, target):
    target.render.fps = source.render.fps
    target.render.fps_base = source.render.fps_base
    target.render.frame_map_old = source.render.frame_map_old
    target.render.frame_map_new = source.render.frame_map_new
    target.frame_start = source.frame_start
    target.frame_end = source.frame_end
    target.render.filter_size = source.render.filter_size
    target.render.use_motion_blur = False

    if source.render.engine == "BLENDER_EEVEE_NEXT":
        _copy_simple_rna_settings(source.eevee, target.eevee)
    elif source.render.engine == "CYCLES":
        _copy_simple_rna_settings(source.cycles, target.cycles)


def _style_render_specs(settings):
    if settings.style_mode == "SINGLE":
        return (
            {
                "key": "single",
                "label": "Single sheet",
                "material": None,
                "outline": settings.use_outline,
            },
        )

    specs = [
        {"key": "kolor", "label": "Color without outline", "material": None, "outline": False},
        {"key": "kolor_kontur", "label": "Color with outline", "material": None, "outline": True},
    ]
    return tuple(specs)


def _style_output_keys(settings):
    if settings.style_mode == "SINGLE":
        return ("single",)
    if settings.style_mode == "COMPARE":
        return COMPARE_STYLE_KEYS
    if settings.style_mode == "FULL":
        return FULL_STYLE_KEYS
    if settings.style_mode == "PIXEL":
        return PIXEL_STYLE_KEYS
    if settings.style_mode == "TIBIA":
        scale = int(settings.tibia_render_scale)
        if settings.tibia_use_outlines:
            return TIBIA_STYLE_KEYS_BY_SCALE[scale]
        return TIBIA_NO_OUTLINE_STYLE_KEYS_BY_SCALE[scale]
    return PIXEL_STYLE_KEYS + TECHNICAL_STYLE_KEYS


COMPARE_STYLE_KEYS = (
    "kolor",
    "kolor_kontur",
    "biale_cieniowanie",
    "toon_3_tony",
    "sylwetka",
    "alpha",
)

FULL_STYLE_KEYS = COMPARE_STYLE_KEYS + (
    "maska_konturu",
    "normalne",
    "glebia",
    "id_obiektow",
)

PIXEL_STYLE_KEYS = (
    "kolor",
    "kolor_kontur",
    "biale_cieniowanie",
    "biale_kontur",
    "toon_2_tony",
    "toon_3_tony",
    "toon_3_kontur",
    "toon_4_tony",
    "pixel_kontrast",
    "pixel_miekki",
    "szarosc",
    "szary_toon_3",
    "paleta_8",
    "paleta_27",
    "paleta_64",
    "paleta_16_dither",
    "pastel",
    "kolor_stonowany",
    "pixel_czytelny",
    "tusz_1bit",
)

TECHNICAL_STYLE_KEYS = (
    "albedo",
    "alpha",
    "sylwetka",
    "maska_konturu",
    "maska_linii",
    "maska_cienia",
    "maska_swiatla",
    "ao",
    "glebia",
    "normalne",
    "id_materialow",
    "id_obiektow",
)

TIBIA_OUTLINE_VARIANTS = (
    ("original", "Original outline"),
    ("dual", "Dual-layer outline"),
)
TIBIA_NO_OUTLINE_VARIANTS = (("none", "No outline"),)
TIBIA_RESAMPLE_VARIANTS = (
    ("nearest", "Nearest"),
    ("area", "Area"),
    ("bicubic", "Bicubic"),
)
TIBIA_SHARPEN_VARIANTS = (
    ("off", "no sharpening", 0.0),
    ("soft", "soft sharpening", 0.08),
    ("medium", "medium sharpening", 0.16),
    ("strong", "strong sharpening", 0.28),
)

TIBIA_VARIANT_META = {}
TIBIA_STYLE_KEYS_BY_SCALE = {}
TIBIA_NO_OUTLINE_STYLE_KEYS_BY_SCALE = {}
for _scale in (4, 8):
    _outlined_keys = []
    _no_outline_keys = []
    for _outline_key, _outline_label in (
        TIBIA_NO_OUTLINE_VARIANTS + TIBIA_OUTLINE_VARIANTS
    ):
        for _resize_key, _resize_label in TIBIA_RESAMPLE_VARIANTS:
            for _sharp_key, _sharp_label, _sharp_amount in TIBIA_SHARPEN_VARIANTS:
                _key = f"td_{_outline_key}_{_scale}x_{_resize_key}_{_sharp_key}"
                if _outline_key == "none":
                    _no_outline_keys.append(_key)
                else:
                    _outlined_keys.append(_key)
                TIBIA_VARIANT_META[_key] = {
                    "outline": _outline_key,
                    "outline_label": _outline_label,
                    "scale": _scale,
                    "resampler": _resize_key,
                    "resampler_label": _resize_label,
                    "sharpen": _sharp_key,
                    "sharpen_label": _sharp_label,
                    "sharpen_amount": _sharp_amount,
                    "label": (
                        f"{_outline_label} · {_scale}× · "
                        f"{_resize_label} · {_sharp_label}"
                    ),
                }
    TIBIA_STYLE_KEYS_BY_SCALE[_scale] = tuple(_outlined_keys)
    TIBIA_NO_OUTLINE_STYLE_KEYS_BY_SCALE[_scale] = tuple(_no_outline_keys)

TIBIA_STYLE_KEYS = tuple(
    key
    for mapping in (
        TIBIA_NO_OUTLINE_STYLE_KEYS_BY_SCALE,
        TIBIA_STYLE_KEYS_BY_SCALE,
    )
    for keys in mapping.values()
    for key in keys
)
DATA_STYLE_KEYS = frozenset(TECHNICAL_STYLE_KEYS)
STANDARD_COLOR_STYLE_KEYS = frozenset(("albedo",) + TIBIA_STYLE_KEYS)


STYLE_LABELS = {
    "single": "Single sheet",
    "kolor": "Natural color",
    "kolor_kontur": "Color + black outline",
    "biale_cieniowanie": "White clay",
    "biale_kontur": "White clay + outline",
    "toon_2_tony": "Toon — 2 levels",
    "toon_3_tony": "Toon — 3 levels",
    "toon_3_kontur": "Toon — 3 levels + outline",
    "toon_4_tony": "Toon — 4 levels",
    "pixel_kontrast": "Pixel — high contrast",
    "pixel_miekki": "Pixel — soft shading",
    "szarosc": "Grayscale",
    "szary_toon_3": "Gray toon — 3 levels",
    "paleta_8": "8-color palette",
    "paleta_27": "27-color palette",
    "paleta_64": "64-color palette",
    "paleta_16_dither": "Retro palette + dithering",
    "pastel": "Pastel pixel",
    "kolor_stonowany": "Muted color",
    "pixel_czytelny": "Readable pixel art + lines",
    "tusz_1bit": "1-bit ink",
    "albedo": "Albedo — flat color",
    "sylwetka": "Silhouette mask",
    "alpha": "Alpha mask",
    "maska_konturu": "Outer outline mask",
    "maska_linii": "Freestyle line mask",
    "maska_cienia": "Shadow mask",
    "maska_swiatla": "Highlight mask",
    "ao": "AO mask",
    "glebia": "Shared depth",
    "normalne": "Camera normals",
    "id_materialow": "Material IDs",
    "id_obiektow": "Object IDs",
}
STYLE_LABELS.update(
    {key: metadata["label"] for key, metadata in TIBIA_VARIANT_META.items()}
)


def _localized_style_label(key):
    metadata = TIBIA_VARIANT_META.get(key)
    if metadata is None:
        return _iface(STYLE_LABELS[key])
    return (
        f"{_iface(metadata['outline_label'])} · {metadata['scale']}× · "
        f"{metadata['resampler_label']} · {_iface(metadata['sharpen_label'])}"
    )


STYLE_CATEGORIES = {
    **{key: "visual_style" for key in PIXEL_STYLE_KEYS},
    "albedo": "recolor_layer",
    "alpha": "mask",
    "sylwetka": "mask",
    "maska_konturu": "mask",
    "maska_linii": "mask",
    "maska_cienia": "mask",
    "maska_swiatla": "mask",
    "ao": "mask",
    "glebia": "data",
    "normalne": "data",
    "id_materialow": "data",
    "id_obiektow": "data",
}
STYLE_CATEGORIES.update({key: "tibiadevs_test" for key in TIBIA_STYLE_KEYS})


POLISH_TRANSLATION_PAIRS = (
    # Source selection and animation.
    ("Source", "Źródło"),
    ("Collection", "Kolekcja"),
    ("Render the entire selected collection", "Renderuj całą wskazaną kolekcję"),
    ("Selection", "Zaznaczenie"),
    ("Render selected objects and their children", "Renderuj zaznaczone obiekty i ich dzieci"),
    ("Include Children", "Uwzględnij dzieci"),
    ("Pivot (optional)", "Pivot (opcjonalnie)"),
    ("Rotation pivot; when empty, uses the model center at foot level", "Punkt obrotu; bez wskazania zostanie użyty środek modelu na poziomie stóp"),
    ("Frame 1", "Klatka 1"),
    ("Frame 2", "Klatka 2"),
    ("Frame 3", "Klatka 3"),
    ("Rows from Top", "Wiersze od góry"),
    ("South, east, north, west", "Południe, wschód, północ, zachód"),
    ("South, west, north, east", "Południe, zachód, północ, wschód"),
    ("Model Front", "Przód modelu"),
    ("The model front points along local -Y", "Przód modelu wskazuje lokalne -Y"),
    ("The model front points along local +Y", "Przód modelu wskazuje lokalne +Y"),
    ("The model front points along local +X", "Przód modelu wskazuje lokalne +X"),
    ("The model front points along local -X", "Przód modelu wskazuje lokalne -X"),
    ("Direction Correction", "Korekta kierunku"),
    # Perspective and size.
    ("Perspective", "Perspektywa"),
    ("Tibia / lattice from file", "Tibia / lattice z pliku"),
    ("Top-down camera and oblique deformation matching the Perspectiva45 file", "Kamera z góry i ukośna deformacja jak w pliku Perspectiva45"),
    ("45° Ortho Camera", "Kamera ortho 45°"),
    ("Classic orthographic camera tilted above the model", "Klasyczna kamera ortograficzna pochylona nad modelem"),
    ("Shear X", "Skos X"),
    ("Shear Y", "Skos Y"),
    ("Z Compression", "Ścisk Z"),
    ("Camera Azimuth", "Azymut kamery"),
    ("Camera Elevation", "Elewacja kamery"),
    ("Width", "Szerokość"),
    ("Height", "Wysokość"),
    ("Padding", "Margines"),
    ("Pixelization Scale", "Skala pikselizacji"),
    ("1.0 renders at full resolution; 0.5 produces 2x2 pixels", "1.0 renderuje w pełnej rozdzielczości; 0.5 daje piksele 2x2"),
    ("TibiaDevs Working Scale", "Skala robocza TibiaDevs"),
    ("Renders each cell at a higher resolution, then downsamples it using three methods", "Renderuje komórkę w wyższej rozdzielczości, a następnie zmniejsza ją trzema metodami"),
    ("4× (faster)", "4× (szybciej)"),
    ("Base render is 4 times larger", "Render bazowy 4 razy większy"),
    ("8× (more detail)", "8× (dokładniej)"),
    ("Base render is 8 times larger; slower", "Render bazowy 8 razy większy; wolniejszy"),
    ("Use TibiaDevs Outlines", "Użyj konturów TibiaDevs"),
    ("Enables two Freestyle outline sets; when disabled, generates 12 variants completely without an outline", "Włącz dwa zestawy z konturem Freestyle; po wyłączeniu generuje 12 wariantów całkowicie bez konturu"),
    ("Vertical Shift", "Przesunięcie pionowe"),
    ("Moves the model inside the cell without changing shared framing", "Przesuwa model w komórce bez zmiany wspólnego kadrowania"),
    # Output modes and style controls.
    ("Output Variants", "Warianty wyjściowe"),
    ("Single Sheet", "Jeden arkusz"),
    ("One standard render using the selected outline settings", "Dotychczasowy pojedynczy render z ustawionym konturem"),
    ("Comparison — 6 Styles", "Porównanie — 6 stylów"),
    ("Color, outlined color, white shading, toon, silhouette and alpha", "Kolor, kolor z konturem, białe cieniowanie, toon, sylwetka i alfa"),
    ("Pixel-art Styles — 20", "Style pixel-art — 20"),
    ("Twenty appearance variants: toon, palettes, dithering, clay, ink and readable pixel art preserving model colors", "Dwadzieścia wariantów wyglądu: toon, palety, dithering, glina, tusz i czytelny pixel-art zachowujący kolory modelu"),
    ("Technical Package — 10", "Pakiet techniczny — 10"),
    ("The comparison package plus outline, normals, depth and object IDs", "Dotychczasowy pakiet porównawczy oraz kontur, normalne, głębia i ID obiektów"),
    ("Full Laboratory — 32", "Pełne laboratorium — 32"),
    ("Twenty pixel-art styles plus twelve masks and technical layers", "Dwadzieścia stylów pixel-art oraz dwanaście masek i warstw technicznych"),
    ("TibiaDevs Test — 12/24", "Test TibiaDevs — 12/24"),
    ("No outline or two outline methods, three downsampling filters and four sharpening levels", "Bez konturu albo dwa kontury, trzy filtry zmniejszania i cztery poziomy wyostrzenia"),
    ("Comparison Sheet", "Arkusz porównawczy"),
    ("Save an additional PNG with variants arranged side by side", "Zapisz dodatkowy PNG z wariantami ułożonymi obok siebie"),
    ("White Style Tint", "Odcień białego stylu"),
    ("Freestyle Outline", "Kontur Freestyle"),
    ("Outline Thickness", "Grubość konturu"),
    ("Outline Color", "Kolor konturu"),
    ("Crisp Alpha", "Twarda alfa"),
    ("Alpha Threshold", "Próg alfa"),
    ("Use Scene Lights", "Użyj świateł sceny"),
    ("PNG File", "Plik PNG"),
    ("Overwrite Existing File", "Nadpisz istniejący plik"),
    # Operators and panel text.
    ("Prepare Model Collection", "Przygotuj kolekcję modelu"),
    ("Creates and selects TIBIA_TARGET without changing scene settings", "Tworzy i wybiera kolekcję TIBIA_TARGET bez zmiany ustawień sceny"),
    ("Generate 3×4 Spritesheet", "Generuj spritesheet 3×4"),
    ("Renders 12 cells and saves one sheet or a style package", "Renderuje 12 komórek i zapisuje jeden arkusz lub pakiet stylów"),
    ("Animation: 3 Columns", "Animacja: 3 kolumny"),
    ("Size and Pixels", "Rozmiar i piksele"),
    ("4×/8× render; output stays at the cell size.", "Render 4×/8×, wynik pozostaje w rozmiarze komórki."),
    ("Output: {width} × {height} px", "Wynik: {width} × {height} px"),
    ("Mode", "Tryb"),
    ("PNG sheets to save: {count}.", "Zostanie zapisanych arkuszy PNG: {count}."),
    ("2 outlines × 3 filters × 4 sharpening levels.", "2 kontury × 3 filtry × 4 poziomy ostrości."),
    ("No outline: 3 filters × 4 sharpening levels.", "Bez konturu: 3 filtry × 4 poziomy ostrości."),
    ("20 appearances + 12 masks and data layers.", "20 wyglądów + 12 masek i warstw danych."),
    ("Style", "Styl"),
    ("Lights: original SUN + adaptive SPOT", "Światła: oryginalny SUN + dopasowany SPOT"),
    ("Colors: Standard, render filter 0.5", "Kolory: Standard, filtr renderu 0.5"),
    ("Thickness is scaled to final output pixels.", "Grubość jest skalowana do końcowych pikseli."),
    ("The outline applies to the color + outline variant.", "Kontur dotyczy wariantu kolor + kontur."),
    ("Freestyle and the black outline are completely disabled.", "Freestyle i czarny kontur są całkowicie wyłączone."),
    ("Save", "Zapis"),
    ("The filename is used as the package prefix.", "Nazwa pliku jest prefiksem całego pakietu."),
    ("Generate Package — {count} Sheets", "Generuj pakiet — {count} arkuszy"),
    ("Rows from top; frames from left.", "Wiersze od góry, klatki od lewej."),
    # Style and TibiaDevs labels used in contact sheets and manifests.
    ("Original outline", "Oryginalny kontur"),
    ("Dual-layer outline", "Kontur dwuwarstwowy"),
    ("No outline", "Bez konturu"),
    ("no sharpening", "bez wyostrzenia"),
    ("soft sharpening", "wyostrzenie lekkie"),
    ("medium sharpening", "wyostrzenie średnie"),
    ("strong sharpening", "wyostrzenie mocne"),
    ("Single sheet", "Pojedynczy arkusz"),
    ("Natural color", "Kolor naturalny"),
    ("Color + black outline", "Kolor + czarny kontur"),
    ("White clay", "Biała glina"),
    ("White clay + outline", "Biała glina + kontur"),
    ("Toon — 2 levels", "Toon — 2 tony"),
    ("Toon — 3 levels", "Toon — 3 tony"),
    ("Toon — 3 levels + outline", "Toon — 3 tony + kontur"),
    ("Toon — 4 levels", "Toon — 4 tony"),
    ("Pixel — high contrast", "Pixel — wysoki kontrast"),
    ("Pixel — soft shading", "Pixel — miękkie cieniowanie"),
    ("Grayscale", "Skala szarości"),
    ("Gray toon — 3 levels", "Szary toon — 3 tony"),
    ("8-color palette", "Paleta 8 kolorów"),
    ("27-color palette", "Paleta 27 kolorów"),
    ("64-color palette", "Paleta 64 kolorów"),
    ("Retro palette + dithering", "Paleta retro + dithering"),
    ("Pastel pixel", "Pastelowy pixel"),
    ("Muted color", "Kolor stonowany"),
    ("Readable pixel art + lines", "Czytelny pixel-art + linie"),
    ("1-bit ink", "Tusz 1-bit"),
    ("Albedo — flat color", "Albedo — płaski kolor"),
    ("Silhouette mask", "Maska sylwetki"),
    ("Alpha mask", "Maska alfa"),
    ("Outer outline mask", "Maska konturu zewnętrznego"),
    ("Freestyle line mask", "Maska linii Freestyle"),
    ("Shadow mask", "Maska ciemnych partii"),
    ("Highlight mask", "Maska jasnych partii"),
    ("AO mask", "Maska AO"),
    ("Shared depth", "Głębia wspólna"),
    ("Camera normals", "Normalne kamery"),
    ("Material IDs", "ID materiałów"),
    ("Object IDs", "ID obiektów"),
    # Reports and errors.
    ("Select a collection containing the model.", "Wskaż kolekcję z modelem."),
    ("Select the model or choose a collection.", "Zaznacz model albo wybierz kolekcję."),
    ("The source contains no visible geometry. Check the collection and Hide in Render.", "W źródle nie ma widocznej geometrii. Sprawdź kolekcję i opcję Hide in Render."),
    ("Could not calculate the model bounds. Try Collection source mode.", "Nie udało się obliczyć obwiedni modelu. Spróbuj trybu Kolekcja."),
    ("The full package requires the OpenImageIO and NumPy modules bundled with Blender.", "Pełny pakiet wymaga modułów OpenImageIO i NumPy dołączonych do Blendera."),
    ("The render size is {actual_width}x{actual_height}, expected {width}x{height}.", "Render ma rozmiar {actual_width}x{actual_height} zamiast {width}x{height}."),
    ("Could not read EXR layers: {filepath}", "Nie można odczytać warstw EXR: {filepath}"),
    ("Could not read pixels from the multilayer EXR.", "Nie można odczytać pikseli z wielowarstwowego EXR."),
    ("Channel {suffix} is missing from the full-package render.", "Brak kanału {suffix} w renderze pełnego pakietu."),
    ("Layer {name} is missing from the full-package render.", "Brak warstwy {name} w renderze pełnego pakietu."),
    ("The render did not return {pass_name} identifiers.", "Render nie zwrócił identyfikatorów {pass_name}."),
    ("The TibiaDevs test requires the NumPy module bundled with Blender.", "Test TibiaDevs wymaga modułu NumPy dołączonego do Blendera."),
    ("The Area filter requires an integer working scale.", "Filtr Area wymaga całkowitej skali roboczej."),
    ("Unknown downsampling filter: {method}", "Nieznany filtr zmniejszania: {method}"),
    ("Rendering was cancelled.", "Render został przerwany."),
    ("The TibiaDevs render was cancelled.", "Render TibiaDevs został przerwany."),
    ("Unknown output style: {key}", "Nieznany styl wyjściowy: {key}"),
    ("Preview {filename} has an invalid size.", "Podgląd {filename} ma nieprawidłowy rozmiar."),
    ("Technical layers require the Eevee or Cycles render engine.", "Warstwy techniczne wymagają silnika Eevee albo Cycles."),
    ("The TIBIA_TARGET collection is ready. Move the model into it and click Generate.", "Kolekcja TIBIA_TARGET jest gotowa. Przenieś do niej model i kliknij Generuj."),
    ("A file already exists: {filename}. Enable overwriting or change the name.", "Plik już istnieje: {filename}. Włącz nadpisywanie albo zmień nazwę."),
    ("Could not prepare the output location: {error}", "Nie można przygotować zapisu: {error}"),
    ("The TibiaDevs test exceeds 2048 px per working cell. Reduce the cell size or select the 4× scale.", "Test TibiaDevs przekracza 2048 px na komórkę. Zmniejsz komórkę albo wybierz skalę 4×."),
    ("This package requires too much memory at the selected size. Reduce the cell size or choose a smaller style mode.", "Ten pakiet przy wybranym rozmiarze wymaga zbyt dużo pamięci. Zmniejsz komórkę albo wybierz mniejszy tryb stylów."),
    ("Finished: {width}×{height}px — {output}", "Gotowe: {width}×{height}px — {output}"),
    (" + comparison sheet", " + arkusz porównawczy"),
    ("Finished: {count} styles{extras} — {directory}", "Gotowe: style: {count}{extras} — {directory}"),
)

TRANSLATIONS = {
    "pl_PL": {
        (I18N_CONTEXT, source): translated
        for source, translated in POLISH_TRANSLATION_PAIRS
    }
}


def _read_rendered_exr(filepath, width, height):
    image = bpy.data.images.load(filepath, check_existing=False)
    try:
        actual = tuple(image.size)
        if actual != (width, height):
            raise TibiaGeneratorError(
                _rpt(
                    "The render size is {actual_width}x{actual_height}, expected {width}x{height}."
                ).format(
                    actual_width=actual[0],
                    actual_height=actual[1],
                    width=width,
                    height=height,
                )
            )
        pixels = array("f", [0.0]) * (width * height * 4)
        image.pixels.foreach_get(pixels)
        alpha_mode = image.alpha_mode
        return pixels, alpha_mode
    finally:
        bpy.data.images.remove(image, do_unlink=True)


def _read_multilayer_exr(
    filepath,
    width,
    height,
    depth_near,
    depth_far,
    world_to_camera,
    extended=False,
):
    """Read beauty and technical passes from Blender's multilayer EXR."""
    try:
        import numpy as np
        import OpenImageIO as oiio
    except ImportError as error:
        raise TibiaGeneratorError(
            "The full package requires the OpenImageIO and NumPy modules bundled with Blender."
        ) from error

    image_input = oiio.ImageInput.open(filepath)
    if image_input is None:
        raise TibiaGeneratorError(
            _rpt("Could not read EXR layers: {filepath}").format(filepath=filepath)
        )
    try:
        spec = image_input.spec()
        if (spec.width, spec.height) != (width, height):
            raise TibiaGeneratorError(
                _rpt(
                    "The render size is {actual_width}x{actual_height}, expected {width}x{height}."
                ).format(
                    actual_width=spec.width,
                    actual_height=spec.height,
                    width=width,
                    height=height,
                )
            )
        pixels = image_input.read_image(format=oiio.FLOAT)
        if pixels is None or getattr(pixels, "ndim", 0) != 3:
            raise TibiaGeneratorError("Could not read pixels from the multilayer EXR.")
        channel_names = tuple(spec.channelnames)
    finally:
        image_input.close()

    lowered = tuple(name.lower() for name in channel_names)

    def channel(suffix):
        suffix = suffix.lower()
        for index, name in enumerate(lowered):
            if name.endswith(suffix):
                return index
        raise TibiaGeneratorError(
            _rpt(
                "Channel {suffix} is missing from the full-package render."
            ).format(suffix=suffix)
        )

    def optional_channel(suffix):
        suffix = suffix.lower()
        for index, name in enumerate(lowered):
            if name.endswith(suffix):
                return index
        return None

    def rgba_array(values):
        flipped = np.ascontiguousarray(np.flipud(values), dtype=np.float32)
        result = array("f")
        result.frombytes(flipped.tobytes())
        return result

    combined = np.stack(
        (
            pixels[:, :, channel("combined.r")],
            pixels[:, :, channel("combined.g")],
            pixels[:, :, channel("combined.b")],
            pixels[:, :, channel("combined.a")],
        ),
        axis=2,
    ).astype(np.float32, copy=False)
    alpha = np.clip(combined[:, :, 3], 0.0, 1.0)

    def rgb_pass(name, required=True):
        indices = tuple(optional_channel(f"{name}.{component}") for component in "rgb")
        if any(index is None for index in indices):
            if required:
                raise TibiaGeneratorError(
                    _rpt(
                        "Layer {name} is missing from the full-package render."
                    ).format(name=name)
                )
            return None
        return np.stack(tuple(pixels[:, :, index] for index in indices), axis=2)

    coverage = alpha[:, :, None]

    def unpremultiply(values):
        return np.divide(
            values,
            coverage,
            out=np.zeros_like(values, dtype=np.float32),
            where=coverage > 1.0e-6,
        )

    def rgba(values):
        result = np.zeros((height, width, 4), dtype=np.float32)
        result[:, :, :3] = values
        result[:, :, 3] = alpha
        return result

    normal_world = unpremultiply(
        np.stack(
            (
                pixels[:, :, channel("normal.x")],
                pixels[:, :, channel("normal.y")],
                pixels[:, :, channel("normal.z")],
            ),
            axis=2,
        )
    )
    camera_matrix = np.asarray(
        [[world_to_camera[row][column] for column in range(3)] for row in range(3)],
        dtype=np.float32,
    )
    normal_xyz = np.einsum("ij,hwj->hwi", camera_matrix, normal_world)
    normal_length = np.linalg.norm(normal_xyz, axis=2, keepdims=True)
    normal_xyz = np.divide(
        normal_xyz,
        normal_length,
        out=np.zeros_like(normal_xyz),
        where=normal_length > 1.0e-6,
    )
    normal_rgba = np.zeros((height, width, 4), dtype=np.float32)
    normal_rgba[:, :, :3] = np.clip(normal_xyz * 0.5 + 0.5, 0.0, 1.0)
    normal_rgba[:, :, 3] = alpha

    depth = pixels[:, :, channel("depth.z")]
    depth_rgba = np.zeros((height, width, 4), dtype=np.float32)
    depth_span = max(depth_far - depth_near, 1.0e-5)
    valid_depth = np.isfinite(depth) & (alpha > 0.0)
    depth_value = np.zeros((height, width), dtype=np.float32)
    depth_value[valid_depth] = np.clip(
        1.0 - (depth[valid_depth] - depth_near) / depth_span,
        0.0,
        1.0,
    )
    depth_rgba[:, :, :3] = depth_value[:, :, None]
    depth_rgba[:, :, 3] = alpha

    def cryptomatte_rgba(pass_name, required=True):
        best_hash = np.zeros((height, width), dtype=np.float32)
        best_coverage = np.zeros((height, width), dtype=np.float32)
        for layer_index in range(3):
            prefix = f"{pass_name}{layer_index:02d}"
            indices = tuple(
                optional_channel(f"{prefix}.{component}")
                for component in ("r", "g", "b", "a")
            )
            if any(index is None for index in indices):
                continue
            for hash_index, coverage_index in (
                (indices[0], indices[1]),
                (indices[2], indices[3]),
            ):
                hash_values = np.ascontiguousarray(
                    pixels[:, :, hash_index], dtype=np.float32
                )
                hash_bits = hash_values.view(np.uint32)
                pass_coverage = pixels[:, :, coverage_index]
                replace = (
                    (hash_bits != 0)
                    & (pass_coverage > best_coverage)
                )
                best_hash[replace] = hash_values[replace]
                best_coverage[replace] = pass_coverage[replace]

        if not np.any(best_coverage > 0.0):
            if required:
                raise TibiaGeneratorError(
                    _rpt(
                        "The render did not return {pass_name} identifiers."
                    ).format(pass_name=pass_name)
                )
            return np.zeros((height, width, 4), dtype=np.float32)
        hash_bits = best_hash.view(np.uint32)
        result = np.zeros((height, width, 4), dtype=np.float32)
        for component, shift in enumerate((0, 8, 16)):
            value = ((hash_bits >> shift) & 255).astype(np.float32) / 255.0
            result[:, :, component] = np.where(
                best_coverage > 0.0, 0.15 + value * 0.85, 0.0
            )
        result[:, :, 3] = alpha
        return result

    object_id_rgba = cryptomatte_rgba("cryptoobject")

    technical = {
        "normalne": rgba_array(normal_rgba),
        "glebia": rgba_array(depth_rgba),
        "id_obiektow": rgba_array(object_id_rgba),
    }
    if extended:
        diffuse_color = unpremultiply(rgb_pass("diffcol"))
        diffuse_direct = rgb_pass("diffdir")
        diffuse_indirect = rgb_pass("diffind", required=False)
        if diffuse_indirect is not None:
            diffuse_direct = diffuse_direct + diffuse_indirect
        diffuse_light = unpremultiply(diffuse_direct)
        ambient_occlusion = unpremultiply(rgb_pass("ao"))
        material_id_rgba = cryptomatte_rgba("cryptomaterial")
        technical.update(
            {
                "albedo": rgba_array(rgba(np.clip(diffuse_color, 0.0, 1.0))),
                "swiatlo_diffuse": rgba_array(
                    rgba(np.maximum(diffuse_light, 0.0))
                ),
                "ao": rgba_array(rgba(np.clip(ambient_occlusion, 0.0, 1.0))),
                "id_materialow": rgba_array(material_id_rgba),
            }
        )
    return rgba_array(combined), "PREMUL", technical


def _resize_nearest(source, source_width, source_height, target_width, target_height):
    if (source_width, source_height) == (target_width, target_height):
        return source
    target = array("f", [0.0]) * (target_width * target_height * 4)
    for y in range(target_height):
        source_y = min(int(y * source_height / target_height), source_height - 1)
        for x in range(target_width):
            source_x = min(int(x * source_width / target_width), source_width - 1)
            src = (source_y * source_width + source_x) * 4
            dst = (y * target_width + x) * 4
            target[dst : dst + 4] = source[src : src + 4]
    return target


def _quality_numpy():
    try:
        import numpy as np
    except ImportError as error:
        raise TibiaGeneratorError(
            "The TibiaDevs test requires the NumPy module bundled with Blender."
        ) from error
    return np


def _array_from_numpy(values):
    np = _quality_numpy()
    contiguous = np.ascontiguousarray(values, dtype=np.float32)
    result = array("f")
    result.frombytes(contiguous.tobytes())
    return result


def _cubic_weights(np, distance):
    """Catmull-Rom cubic kernel used by the quality comparison path."""
    absolute = np.abs(distance)
    first = 1.5 * absolute**3 - 2.5 * absolute**2 + 1.0
    second = -0.5 * absolute**3 + 2.5 * absolute**2 - 4.0 * absolute + 2.0
    return np.where(absolute <= 1.0, first, np.where(absolute < 2.0, second, 0.0))


def _resize_quality_cell(
    source,
    alpha_mode,
    source_width,
    source_height,
    target_width,
    target_height,
    method,
):
    """Resize RGBA in premultiplied space, then return straight alpha.

    Filtering straight RGB mixes edge colors with transparent black and creates
    dark halos.  Premultiplication keeps all three comparison filters safe.
    """
    np = _quality_numpy()
    values = np.frombuffer(source, dtype=np.float32).reshape(
        source_height, source_width, 4
    ).copy()
    alpha = np.clip(values[:, :, 3:4], 0.0, 1.0)
    if alpha_mode != "PREMUL":
        values[:, :, :3] *= alpha
    values[:, :, 3:4] = alpha

    if (source_width, source_height) == (target_width, target_height):
        resized = values
    elif method == "nearest":
        x = np.minimum(
            ((np.arange(target_width) + 0.5) * source_width / target_width).astype(int),
            source_width - 1,
        )
        y = np.minimum(
            ((np.arange(target_height) + 0.5) * source_height / target_height).astype(int),
            source_height - 1,
        )
        resized = values[y[:, None], x[None, :], :]
    elif method == "area":
        if source_width % target_width or source_height % target_height:
            raise TibiaGeneratorError(
                "The Area filter requires an integer working scale."
            )
        factor_x = source_width // target_width
        factor_y = source_height // target_height
        resized = values.reshape(
            target_height,
            factor_y,
            target_width,
            factor_x,
            4,
        ).mean(axis=(1, 3))
    elif method == "bicubic":
        x_position = (
            (np.arange(target_width, dtype=np.float32) + 0.5)
            * source_width
            / target_width
            - 0.5
        )
        y_position = (
            (np.arange(target_height, dtype=np.float32) + 0.5)
            * source_height
            / target_height
            - 0.5
        )
        x_base = np.floor(x_position).astype(int)
        y_base = np.floor(y_position).astype(int)
        resized = np.zeros((target_height, target_width, 4), dtype=np.float32)
        for y_offset in (-1, 0, 1, 2):
            source_y = np.clip(y_base + y_offset, 0, source_height - 1)
            weight_y = _cubic_weights(np, y_position - (y_base + y_offset))
            for x_offset in (-1, 0, 1, 2):
                source_x = np.clip(x_base + x_offset, 0, source_width - 1)
                weight_x = _cubic_weights(np, x_position - (x_base + x_offset))
                resized += (
                    values[source_y[:, None], source_x[None, :], :]
                    * weight_y[:, None, None]
                    * weight_x[None, :, None]
                )
    else:
        raise TibiaGeneratorError(
            _rpt("Unknown downsampling filter: {method}").format(method=method)
        )

    resized = np.asarray(resized, dtype=np.float32)
    output_alpha = np.clip(resized[:, :, 3:4], 0.0, 1.0)
    output_rgb = np.divide(
        resized[:, :, :3],
        output_alpha,
        out=np.zeros_like(resized[:, :, :3]),
        where=output_alpha > 1.0e-6,
    )
    output_rgb = np.clip(output_rgb, 0.0, 16.0)
    output = np.concatenate((output_rgb, output_alpha), axis=2)
    return _array_from_numpy(output), "STRAIGHT"


def _sharpen_quality_cell(source, width, height, amount):
    if amount <= 0.0:
        return array("f", source), "STRAIGHT"

    np = _quality_numpy()
    values = np.frombuffer(source, dtype=np.float32).reshape(height, width, 4).copy()
    alpha = np.clip(values[:, :, 3:4], 0.0, 1.0)
    linear = np.clip(values[:, :, :3], 0.0, 1.0)
    display = np.where(
        linear <= 0.0031308,
        linear * 12.92,
        1.055 * np.power(linear, 1.0 / 2.4) - 0.055,
    )

    padded_rgb = np.pad(display, ((1, 1), (1, 1), (0, 0)), mode="edge")
    padded_alpha = np.pad(alpha, ((1, 1), (1, 1), (0, 0)), mode="edge")
    center = padded_rgb[1:-1, 1:-1]
    neighbors = []
    for rgb_neighbor, alpha_neighbor in (
        (padded_rgb[:-2, 1:-1], padded_alpha[:-2, 1:-1]),
        (padded_rgb[2:, 1:-1], padded_alpha[2:, 1:-1]),
        (padded_rgb[1:-1, :-2], padded_alpha[1:-1, :-2]),
        (padded_rgb[1:-1, 2:], padded_alpha[1:-1, 2:]),
    ):
        neighbors.append(np.where(alpha_neighbor > 1.0e-6, rgb_neighbor, center))
    detail = center * 4.0 - sum(neighbors)
    sharpened = np.clip(center + amount * detail, 0.0, 1.0)
    sharpened = np.where(alpha > 1.0e-6, sharpened, 0.0)
    linear_output = np.where(
        sharpened <= 0.04045,
        sharpened / 12.92,
        np.power((sharpened + 0.055) / 1.055, 2.4),
    )
    output = np.concatenate((linear_output, alpha), axis=2)
    return _array_from_numpy(output), "STRAIGHT"


def _threshold_alpha(pixels, threshold, premultiplied=False):
    for index in range(3, len(pixels), 4):
        alpha = pixels[index]
        if alpha < threshold:
            pixels[index - 3] = 0.0
            pixels[index - 2] = 0.0
            pixels[index - 1] = 0.0
            pixels[index] = 0.0
        else:
            if premultiplied and alpha > 1.0e-8:
                pixels[index - 3] /= alpha
                pixels[index - 2] /= alpha
                pixels[index - 1] /= alpha
            pixels[index] = 1.0


def _blit(sheet, sheet_width, cell, cell_width, cell_height, column, row):
    target_y = (4 - 1 - row) * cell_height
    row_length = cell_width * 4
    for source_y in range(cell_height):
        source_start = source_y * row_length
        destination_y = target_y + source_y
        destination_start = (
            destination_y * sheet_width * 4 + column * cell_width * 4
        )
        sheet[destination_start : destination_start + row_length] = cell[
            source_start : source_start + row_length
        ]


def _blit_alpha(sheet, sheet_width, cell, cell_width, cell_height, column, row):
    target_y = (4 - 1 - row) * cell_height
    for source_y in range(cell_height):
        destination_y = target_y + source_y
        for source_x in range(cell_width):
            source_index = (source_y * cell_width + source_x) * 4 + 3
            destination_index = (
                destination_y * sheet_width + column * cell_width + source_x
            )
            sheet[destination_index] = cell[source_index]


def _render_style_sheet(
    context,
    temp_scene,
    instancer,
    frames,
    rows,
    direction_matrices,
    settings,
    render_width,
    render_height,
    temp_directory,
    style_key,
    progress,
    technical_config=None,
):
    sheet_width = settings.cell_width * 3
    sheet_height = settings.cell_height * 4
    sheet_pixels = array("f", [0.0]) * (sheet_width * sheet_height * 4)
    soft_alpha = array("f", [0.0]) * (sheet_width * sheet_height)
    alpha_mode = "STRAIGHT"

    temp_scene.render.image_settings.file_format = (
        "OPEN_EXR_MULTILAYER" if technical_config is not None else "OPEN_EXR"
    )
    temp_scene.render.image_settings.color_mode = "RGBA"
    temp_scene.render.image_settings.color_depth = "32"
    temp_scene.render.image_settings.exr_codec = "ZIP"

    with _scene_override(context, temp_scene):
        for column, frame in enumerate(frames):
            temp_scene.frame_set(frame)
            for row, (direction_label, _angle) in enumerate(rows):
                instancer.matrix_basis = direction_matrices[row]
                context.view_layer.update()
                exr_path = os.path.join(
                    temp_directory,
                    f"{_safe_name(style_key)}_{column}_{row}_{_safe_name(direction_label)}.exr",
                )
                temp_scene.render.filepath = exr_path
                result = bpy.ops.render.render(
                    scene=temp_scene.name,
                    write_still=True,
                    use_viewport=False,
                )
                if "FINISHED" not in result:
                    raise TibiaGeneratorError("Rendering was cancelled.")
                if technical_config is None:
                    cell, alpha_mode = _read_rendered_exr(
                        exr_path, render_width, render_height
                    )
                    technical_cells = None
                else:
                    cell, alpha_mode, technical_cells = _read_multilayer_exr(
                        exr_path,
                        render_width,
                        render_height,
                        technical_config["depth_near"],
                        technical_config["depth_far"],
                        technical_config["world_to_camera"],
                        extended=technical_config["extended"],
                    )
                cell = _resize_nearest(
                    cell,
                    render_width,
                    render_height,
                    settings.cell_width,
                    settings.cell_height,
                )
                if technical_cells is not None:
                    for key, technical_cell in technical_cells.items():
                        technical_cell = _resize_nearest(
                            technical_cell,
                            render_width,
                            render_height,
                            settings.cell_width,
                            settings.cell_height,
                        )
                        _blit(
                            technical_config["sheets"][key],
                            sheet_width,
                            technical_cell,
                            settings.cell_width,
                            settings.cell_height,
                            column,
                            row,
                        )
                _blit_alpha(
                    soft_alpha,
                    sheet_width,
                    cell,
                    settings.cell_width,
                    settings.cell_height,
                    column,
                    row,
                )
                if settings.crisp_alpha:
                    _threshold_alpha(
                        cell,
                        settings.alpha_threshold,
                        premultiplied=(alpha_mode == "PREMUL"),
                    )
                    alpha_mode = "STRAIGHT"
                _blit(
                    sheet_pixels,
                    sheet_width,
                    cell,
                    settings.cell_width,
                    settings.cell_height,
                    column,
                    row,
                )
                progress[0] += 1
                context.window_manager.progress_update(progress[0])

    return sheet_pixels, alpha_mode, soft_alpha


def _render_tibiadevs_sheets(
    context,
    temp_scene,
    instancer,
    frames,
    rows,
    direction_matrices,
    settings,
    render_width,
    render_height,
    temp_directory,
    progress,
):
    """Render the selected TibiaDevs sources and derive comparison sheets.

    With outlines enabled each 3D cell is rendered twice (original and dual
    Freestyle); without outlines it is rendered once.  Resampling and
    sharpening combinations reuse those float EXR pixels.
    """
    scale = int(settings.tibia_render_scale)
    output_keys = _style_output_keys(settings)
    sheet_width = settings.cell_width * 3
    sheet_height = settings.cell_height * 4
    records = {
        key: {
            "pixels": array("f", [0.0]) * (sheet_width * sheet_height * 4),
            "alpha_mode": "STRAIGHT",
        }
        for key in output_keys
    }

    temp_scene.render.image_settings.file_format = "OPEN_EXR"
    temp_scene.render.image_settings.color_mode = "RGBA"
    temp_scene.render.image_settings.color_depth = "32"
    temp_scene.render.image_settings.exr_codec = "ZIP"

    outline_variants = (
        TIBIA_OUTLINE_VARIANTS
        if settings.tibia_use_outlines
        else TIBIA_NO_OUTLINE_VARIANTS
    )
    for outline_key, _outline_label in outline_variants:
        if outline_key == "none":
            outline_mode = "STANDARD"
        elif outline_key == "original":
            outline_mode = "TIBIA_ORIGINAL"
        else:
            outline_mode = "TIBIA_DUAL"
        _configure_outline(
            temp_scene,
            settings,
            enabled=outline_key != "none",
            mode=outline_mode,
            render_scale=float(scale),
        )
        outline_keys = [
            key
            for key in output_keys
            if TIBIA_VARIANT_META[key]["outline"] == outline_key
        ]

        with _scene_override(context, temp_scene):
            for column, frame in enumerate(frames):
                temp_scene.frame_set(frame)
                for row, (direction_label, _angle) in enumerate(rows):
                    instancer.matrix_basis = direction_matrices[row]
                    context.view_layer.update()
                    exr_path = os.path.join(
                        temp_directory,
                        f"td_{outline_key}_{column}_{row}_{_safe_name(direction_label)}.exr",
                    )
                    temp_scene.render.filepath = exr_path
                    result = bpy.ops.render.render(
                        scene=temp_scene.name,
                        write_still=True,
                        use_viewport=False,
                    )
                    if "FINISHED" not in result:
                        raise TibiaGeneratorError("The TibiaDevs render was cancelled.")
                    source, source_alpha_mode = _read_rendered_exr(
                        exr_path, render_width, render_height
                    )

                    resized_by_method = {}
                    for method, _method_label in TIBIA_RESAMPLE_VARIANTS:
                        resized_by_method[method] = _resize_quality_cell(
                            source,
                            source_alpha_mode,
                            render_width,
                            render_height,
                            settings.cell_width,
                            settings.cell_height,
                            method,
                        )[0]

                    for key in outline_keys:
                        metadata = TIBIA_VARIANT_META[key]
                        cell, alpha_mode = _sharpen_quality_cell(
                            resized_by_method[metadata["resampler"]],
                            settings.cell_width,
                            settings.cell_height,
                            metadata["sharpen_amount"],
                        )
                        if settings.crisp_alpha:
                            _threshold_alpha(
                                cell,
                                settings.alpha_threshold,
                                premultiplied=False,
                            )
                            alpha_mode = "STRAIGHT"
                        records[key]["alpha_mode"] = alpha_mode
                        _blit(
                            records[key]["pixels"],
                            sheet_width,
                            cell,
                            settings.cell_width,
                            settings.cell_height,
                            column,
                            row,
                        )

                    progress[0] += 1
                    context.window_manager.progress_update(progress[0])

    return records


def _to_straight_pixels(source, alpha_mode):
    result = array("f", source)
    if alpha_mode != "PREMUL":
        return result
    for index in range(0, len(result), 4):
        alpha = result[index + 3]
        if alpha > 1.0e-8:
            result[index] /= alpha
            result[index + 1] /= alpha
            result[index + 2] /= alpha
        else:
            result[index] = 0.0
            result[index + 1] = 0.0
            result[index + 2] = 0.0
    return result


def _make_clay_shading(source, alpha_mode, tint):
    """Turn the beauty render into a warm, nearly white shaded preview.

    Deriving it from the original render keeps texture cutouts (hair cards,
    leaves, cloth fringes) that a global material override would lose.
    """
    result = _to_straight_pixels(source, alpha_mode)
    tint_peak = max(max(tint), 1.0e-5)
    normalized_tint = tuple(channel / tint_peak for channel in tint)
    for index in range(0, len(result), 4):
        if result[index + 3] <= 0.0:
            continue
        luminance = max(
            0.0,
            min(
                1.0,
                result[index] * 0.2126
                + result[index + 1] * 0.7152
                + result[index + 2] * 0.0722,
            ),
        )
        shade = 0.42 + 0.56 * (luminance ** 0.45)
        result[index] = min(1.0, normalized_tint[0] * shade)
        result[index + 1] = min(1.0, normalized_tint[1] * shade)
        result[index + 2] = min(1.0, normalized_tint[2] * shade)
    return result, "STRAIGHT"


def _clamp01(value):
    return max(0.0, min(1.0, value))


def _linear_to_display(value):
    value = _clamp01(value)
    if value <= 0.0031308:
        return value * 12.92
    return 1.055 * (value ** (1.0 / 2.4)) - 0.055


def _display_to_linear(value):
    value = _clamp01(value)
    if value <= 0.04045:
        return value / 12.92
    return ((value + 0.055) / 1.055) ** 2.4


def _make_toon_levels(source, alpha_mode, tint, levels):
    result = _to_straight_pixels(source, alpha_mode)
    tint_peak = max(max(tint), 1.0e-5)
    normalized_tint = tuple(channel / tint_peak for channel in tint)
    levels = max(2, int(levels))
    for index in range(0, len(result), 4):
        if result[index + 3] <= 0.0:
            continue
        display_rgb = tuple(
            _linear_to_display(result[index + channel]) for channel in range(3)
        )
        luminance = (
            display_rgb[0] * 0.2126
            + display_rgb[1] * 0.7152
            + display_rgb[2] * 0.0722
        )
        band = round(luminance * (levels - 1)) / (levels - 1)
        tone = 0.18 + band * 0.77
        color_peak = max(*display_rgb, 1.0e-5)
        for channel in range(3):
            hue = display_rgb[channel] / color_peak
            mixed = hue * 0.88 + normalized_tint[channel] * 0.12
            result[index + channel] = _display_to_linear(mixed * tone)
    return result, "STRAIGHT"


def _make_toon(source, alpha_mode, tint):
    return _make_toon_levels(source, alpha_mode, tint, 3)


def _make_adjusted_style(
    source,
    alpha_mode,
    contrast=1.0,
    saturation=1.0,
    lift=0.0,
    tint=(1.0, 1.0, 1.0),
):
    result = _to_straight_pixels(source, alpha_mode)
    for index in range(0, len(result), 4):
        if result[index + 3] <= 0.0:
            continue
        display_rgb = [
            _linear_to_display(result[index + channel]) for channel in range(3)
        ]
        luminance = (
            display_rgb[0] * 0.2126
            + display_rgb[1] * 0.7152
            + display_rgb[2] * 0.0722
        )
        for channel in range(3):
            value = luminance + (display_rgb[channel] - luminance) * saturation
            value = (value - 0.5) * contrast + 0.5 + lift
            result[index + channel] = _display_to_linear(value * tint[channel])
    return result, "STRAIGHT"


def _make_grayscale(source, alpha_mode, levels=None, tint=(1.0, 1.0, 1.0)):
    result = _to_straight_pixels(source, alpha_mode)
    for index in range(0, len(result), 4):
        if result[index + 3] <= 0.0:
            continue
        display_rgb = tuple(
            _linear_to_display(result[index + channel]) for channel in range(3)
        )
        luminance = (
            display_rgb[0] * 0.2126
            + display_rgb[1] * 0.7152
            + display_rgb[2] * 0.0722
        )
        if levels is not None:
            levels = max(2, int(levels))
            luminance = 0.12 + (
                round(luminance * (levels - 1)) / (levels - 1)
            ) * 0.84
        for channel in range(3):
            result[index + channel] = _display_to_linear(
                luminance * tint[channel]
            )
    return result, "STRAIGHT"


def _make_posterized(
    source,
    alpha_mode,
    levels,
    width,
    height,
    cell_width,
    cell_height,
    dither=False,
):
    result = _to_straight_pixels(source, alpha_mode)
    levels = max(2, int(levels))
    bayer = (
        (0, 8, 2, 10),
        (12, 4, 14, 6),
        (3, 11, 1, 9),
        (15, 7, 13, 5),
    )
    for y in range(height):
        local_y = y % cell_height
        for x in range(width):
            index = (y * width + x) * 4
            if result[index + 3] <= 0.0:
                continue
            local_x = x % cell_width
            offset = 0.0
            if dither:
                offset = (bayer[local_y % 4][local_x % 4] - 7.5) / (
                    16.0 * (levels - 1)
                )
            for channel in range(3):
                value = _linear_to_display(result[index + channel]) + offset
                quantized = round(_clamp01(value) * (levels - 1)) / (levels - 1)
                result[index + channel] = _display_to_linear(quantized)
    return result, "STRAIGHT"


def _make_readable_pixel_style(
    source,
    alpha_mode,
    line_mask,
    width,
    height,
    cell_width,
    cell_height,
    outline_color,
):
    """Crisp, low-band pixel art that preserves the model's original hues."""
    adjusted, adjusted_mode = _make_adjusted_style(
        source,
        alpha_mode,
        contrast=1.18,
        saturation=1.05,
        lift=-0.015,
    )
    posterized, posterized_mode = _make_posterized(
        adjusted,
        adjusted_mode,
        4,
        width,
        height,
        cell_width,
        cell_height,
    )
    return _apply_line_overlay(
        posterized,
        posterized_mode,
        line_mask,
        outline_color,
    )


def _make_render_line_mask(base, base_alpha_mode, outlined, outlined_alpha_mode):
    base_pixels = _to_straight_pixels(base, base_alpha_mode)
    outlined_pixels = _to_straight_pixels(outlined, outlined_alpha_mode)
    result = array("f", [0.0]) * len(base_pixels)
    for index in range(0, len(result), 4):
        color_delta = max(
            abs(base_pixels[index + channel] - outlined_pixels[index + channel])
            for channel in range(3)
        )
        alpha_delta = max(0.0, outlined_pixels[index + 3] - base_pixels[index + 3])
        value = _clamp01(max(alpha_delta * 3.0, (color_delta - 0.015) * 5.0))
        result[index] = value
        result[index + 1] = value
        result[index + 2] = value
        result[index + 3] = 1.0
    return result, "STRAIGHT"


def _apply_line_overlay(source, alpha_mode, line_mask, color):
    result = _to_straight_pixels(source, alpha_mode)
    for index in range(0, len(result), 4):
        amount = _clamp01(line_mask[index])
        if amount <= 0.0:
            continue
        for channel in range(3):
            result[index + channel] = (
                result[index + channel] * (1.0 - amount)
                + color[channel] * amount
            )
        result[index + 3] = max(result[index + 3], amount)
    return result, "STRAIGHT"


def _make_ink_style(source, alpha_mode, line_mask):
    result, _mode = _make_grayscale(source, alpha_mode, levels=2)
    for index in range(0, len(result), 4):
        base_alpha = result[index + 3]
        line = _clamp01(line_mask[index])
        if base_alpha <= 0.0 and line <= 0.0:
            continue
        value = 0.0 if line >= 0.12 else (1.0 if result[index] >= 0.18 else 0.0)
        result[index] = value
        result[index + 1] = value
        result[index + 2] = value
        result[index + 3] = max(base_alpha, line)
    return result, "STRAIGHT"


def _make_light_mask(source, alpha_mode, invert=False, hdr=False):
    pixels = _to_straight_pixels(source, alpha_mode)
    result = array("f", [0.0]) * len(pixels)
    for index in range(0, len(result), 4):
        if pixels[index + 3] <= 0.0:
            result[index + 3] = 1.0
            continue
        luminance = max(
            0.0,
            pixels[index] * 0.2126
            + pixels[index + 1] * 0.7152
            + pixels[index + 2] * 0.0722,
        )
        if hdr:
            luminance = luminance / (1.0 + luminance)
        else:
            luminance = _clamp01(luminance)
        value = 1.0 - luminance if invert else luminance
        value = _clamp01((value - 0.05) / 0.90)
        result[index] = value
        result[index + 1] = value
        result[index + 2] = value
        result[index + 3] = 1.0
    return result, "STRAIGHT"


def _apply_reference_alpha(source, alpha_mode, soft_alpha, crisp, threshold):
    """Apply beauty-render alpha to technical material-override renders."""
    result = _to_straight_pixels(source, alpha_mode)
    for pixel_index, reference in enumerate(soft_alpha):
        index = pixel_index * 4
        if crisp:
            alpha = 1.0 if reference >= threshold else 0.0
        else:
            alpha = max(0.0, min(1.0, reference))
        if alpha <= 0.0:
            result[index] = 0.0
            result[index + 1] = 0.0
            result[index + 2] = 0.0
        result[index + 3] = alpha
    return result, "STRAIGHT"


def _make_silhouette_mask(soft_alpha, threshold):
    result = array("f", [0.0]) * (len(soft_alpha) * 4)
    for pixel_index, alpha in enumerate(soft_alpha):
        value = 1.0 if alpha >= threshold else 0.0
        target = pixel_index * 4
        result[target] = value
        result[target + 1] = value
        result[target + 2] = value
        result[target + 3] = 1.0
    return result, "STRAIGHT"


def _make_alpha_mask(soft_alpha):
    result = array("f", [0.0]) * (len(soft_alpha) * 4)
    for pixel_index, alpha in enumerate(soft_alpha):
        value = max(0.0, min(1.0, alpha))
        target = pixel_index * 4
        result[target] = value
        result[target + 1] = value
        result[target + 2] = value
        result[target + 3] = 1.0
    return result, "STRAIGHT"


def _make_outline_mask(
    soft_alpha, width, height, cell_width, cell_height, threshold, radius
):
    """Build a clipped outer outline in O(width*height), independently per cell."""
    result = array("f", [0.0]) * (width * height * 4)
    radius = max(1, int(round(radius)))

    for cell_y in range(0, height, cell_height):
        local_height = min(cell_height, height - cell_y)
        for cell_x in range(0, width, cell_width):
            local_width = min(cell_width, width - cell_x)
            prefix_width = local_width + 1
            prefix = array("I", [0]) * (prefix_width * (local_height + 1))

            for local_y in range(local_height):
                row_sum = 0
                source_y = cell_y + local_y
                prefix_row = (local_y + 1) * prefix_width
                previous_row = local_y * prefix_width
                for local_x in range(local_width):
                    source_x = cell_x + local_x
                    if soft_alpha[source_y * width + source_x] >= threshold:
                        row_sum += 1
                    prefix[prefix_row + local_x + 1] = (
                        prefix[previous_row + local_x + 1] + row_sum
                    )

            for local_y in range(local_height):
                source_y = cell_y + local_y
                top = max(0, local_y - radius)
                bottom = min(local_height - 1, local_y + radius)
                for local_x in range(local_width):
                    source_x = cell_x + local_x
                    pixel_index = source_y * width + source_x
                    center_inside = soft_alpha[pixel_index] >= threshold
                    value = 0.0
                    if not center_inside:
                        left = max(0, local_x - radius)
                        right = min(local_width - 1, local_x + radius)
                        inside_count = (
                            prefix[(bottom + 1) * prefix_width + right + 1]
                            - prefix[top * prefix_width + right + 1]
                            - prefix[(bottom + 1) * prefix_width + left]
                            + prefix[top * prefix_width + left]
                        )
                        if inside_count > 0:
                            value = 1.0
                    target = pixel_index * 4
                    result[target] = value
                    result[target + 1] = value
                    result[target + 2] = value
                    result[target + 3] = 1.0
    return result, "STRAIGHT"


def _build_style_record(key, sources, settings, width, height):
    beauty = sources["kolor"]
    outline = sources["kolor_kontur"]
    soft_alpha = sources["soft_alpha"]
    line_mask = sources.get("line_mask")
    technical = sources.get("technical") or {}

    def record(pixels, alpha_mode):
        return {"pixels": pixels, "alpha_mode": alpha_mode}

    if key == "kolor":
        return record(beauty["pixels"], beauty["alpha_mode"])
    if key == "kolor_kontur":
        return record(outline["pixels"], outline["alpha_mode"])
    if key == "biale_cieniowanie":
        return record(
            *_make_clay_shading(
                beauty["pixels"], beauty["alpha_mode"], settings.clay_color
            )
        )
    if key == "biale_kontur":
        pixels, alpha_mode = _make_clay_shading(
            beauty["pixels"], beauty["alpha_mode"], settings.clay_color
        )
        return record(
            *_apply_line_overlay(
                pixels, alpha_mode, line_mask, settings.outline_color
            )
        )
    if key == "toon_2_tony":
        return record(
            *_make_toon_levels(
                beauty["pixels"], beauty["alpha_mode"], settings.clay_color, 2
            )
        )
    if key == "toon_3_tony":
        return record(
            *_make_toon_levels(
                beauty["pixels"], beauty["alpha_mode"], settings.clay_color, 3
            )
        )
    if key == "toon_3_kontur":
        pixels, alpha_mode = _make_toon_levels(
            beauty["pixels"], beauty["alpha_mode"], settings.clay_color, 3
        )
        return record(
            *_apply_line_overlay(
                pixels, alpha_mode, line_mask, settings.outline_color
            )
        )
    if key == "toon_4_tony":
        return record(
            *_make_toon_levels(
                beauty["pixels"], beauty["alpha_mode"], settings.clay_color, 4
            )
        )
    if key == "pixel_kontrast":
        adjusted, alpha_mode = _make_adjusted_style(
            beauty["pixels"],
            beauty["alpha_mode"],
            contrast=1.42,
            saturation=1.18,
            lift=-0.025,
        )
        return record(
            *_make_posterized(
                adjusted,
                alpha_mode,
                4,
                width,
                height,
                settings.cell_width,
                settings.cell_height,
            )
        )
    if key == "pixel_miekki":
        return record(
            *_make_adjusted_style(
                beauty["pixels"],
                beauty["alpha_mode"],
                contrast=0.76,
                saturation=0.82,
                lift=0.065,
            )
        )
    if key == "szarosc":
        return record(*_make_grayscale(beauty["pixels"], beauty["alpha_mode"]))
    if key == "szary_toon_3":
        return record(
            *_make_grayscale(beauty["pixels"], beauty["alpha_mode"], levels=3)
        )
    if key in {"paleta_8", "paleta_27", "paleta_64"}:
        levels = {"paleta_8": 2, "paleta_27": 3, "paleta_64": 4}[key]
        return record(
            *_make_posterized(
                beauty["pixels"],
                beauty["alpha_mode"],
                levels,
                width,
                height,
                settings.cell_width,
                settings.cell_height,
            )
        )
    if key == "paleta_16_dither":
        return record(
            *_make_posterized(
                beauty["pixels"],
                beauty["alpha_mode"],
                3,
                width,
                height,
                settings.cell_width,
                settings.cell_height,
                dither=True,
            )
        )
    if key == "pastel":
        return record(
            *_make_adjusted_style(
                beauty["pixels"],
                beauty["alpha_mode"],
                contrast=0.70,
                saturation=0.52,
                lift=0.16,
                tint=(1.0, 0.97, 0.93),
            )
        )
    if key == "kolor_stonowany":
        return record(
            *_make_adjusted_style(
                beauty["pixels"],
                beauty["alpha_mode"],
                contrast=0.92,
                saturation=0.45,
                lift=0.02,
            )
        )
    if key == "pixel_czytelny":
        return record(
            *_make_readable_pixel_style(
                beauty["pixels"],
                beauty["alpha_mode"],
                line_mask,
                width,
                height,
                settings.cell_width,
                settings.cell_height,
                settings.outline_color,
            )
        )
    if key == "tusz_1bit":
        return record(
            *_make_ink_style(beauty["pixels"], beauty["alpha_mode"], line_mask)
        )
    if key == "alpha":
        return record(*_make_alpha_mask(soft_alpha))
    if key == "sylwetka":
        return record(*_make_silhouette_mask(soft_alpha, settings.alpha_threshold))
    if key == "maska_konturu":
        return record(
            *_make_outline_mask(
                soft_alpha,
                width,
                height,
                settings.cell_width,
                settings.cell_height,
                settings.alpha_threshold,
                settings.outline_thickness,
            )
        )
    if key == "maska_linii":
        return record(line_mask, "STRAIGHT")
    if key in {"maska_cienia", "maska_swiatla"}:
        return record(
            *_make_light_mask(
                technical["swiatlo_diffuse"],
                "STRAIGHT",
                invert=(key == "maska_cienia"),
                hdr=True,
            )
        )
    if key == "ao":
        return record(*_make_light_mask(technical["ao"], "STRAIGHT"))
    if key in {"albedo", "normalne", "glebia", "id_materialow", "id_obiektow"}:
        pixels, alpha_mode = _apply_reference_alpha(
            technical[key],
            "STRAIGHT",
            soft_alpha,
            settings.crisp_alpha,
            settings.alpha_threshold,
        )
        return record(pixels, alpha_mode)
    raise TibiaGeneratorError(
        _rpt("Unknown output style: {key}").format(key=key)
    )


def _save_pixels_png(
    pixels,
    width,
    height,
    alpha_mode,
    filepath,
    scene,
    name,
    data_output=False,
    standard_output=False,
):
    image = bpy.data.images.new(
        name,
        width=width,
        height=height,
        alpha=True,
        float_buffer=True,
    )
    view_settings = scene.view_settings
    saved_view = None
    try:
        if data_output or standard_output:
            saved_view = (
                view_settings.view_transform,
                view_settings.look,
                view_settings.exposure,
                view_settings.gamma,
                view_settings.use_curve_mapping,
            )
            view_settings.view_transform = "Raw" if data_output else "Standard"
            view_settings.look = "None"
            view_settings.exposure = 0.0
            view_settings.gamma = 1.0
            view_settings.use_curve_mapping = False
        image.alpha_mode = alpha_mode
        if data_output:
            image.colorspace_settings.name = "Non-Color"
        image.pixels.foreach_set(pixels)
        image.update()
        scene.render.image_settings.file_format = "PNG"
        scene.render.image_settings.color_mode = "RGBA"
        scene.render.image_settings.color_depth = "8"
        image.filepath_raw = filepath
        image.save_render(filepath, scene=scene)
    finally:
        if saved_view is not None:
            (
                view_settings.view_transform,
                view_settings.look,
                view_settings.exposure,
                view_settings.gamma,
                view_settings.use_curve_mapping,
            ) = saved_view
        bpy.data.images.remove(image, do_unlink=True)


def _contact_thumbnail_size(style_count, sheet_width, sheet_height):
    if style_count <= 6:
        cap_width, cap_height = 240, 320
    elif style_count <= 10:
        cap_width, cap_height = 180, 240
    else:
        cap_width, cap_height = 144, 192
    scale = min(
        1.0,
        cap_width / max(sheet_width, 1),
        cap_height / max(sheet_height, 1),
    )
    return (
        max(1, round(sheet_width * scale)),
        max(1, round(sheet_height * scale)),
    )


def _make_contact_thumbnail(record, sheet_width, sheet_height, width, height):
    pixels = _resize_nearest(
        record["pixels"], sheet_width, sheet_height, width, height
    )
    return {
        "pixels": array("f", pixels),
        "alpha_mode": record["alpha_mode"],
        "key": record["key"],
        "label": record["label"],
    }


def _load_saved_contact_thumbnail(
    filepath, key, label, sheet_width, sheet_height, width, height
):
    """Read the final 8-bit PNG so the contact preview matches every output transform."""
    image = bpy.data.images.load(filepath, check_existing=False)
    try:
        if tuple(image.size) != (sheet_width, sheet_height):
            raise TibiaGeneratorError(
                _rpt("Preview {filename} has an invalid size.").format(
                    filename=os.path.basename(filepath)
                )
            )
        image.colorspace_settings.name = "Non-Color"
        pixels = array("f", [0.0]) * (sheet_width * sheet_height * 4)
        image.pixels.foreach_get(pixels)
        return _make_contact_thumbnail(
            {
                "pixels": pixels,
                "alpha_mode": "STRAIGHT",
                "key": key,
                "label": label,
            },
            sheet_width,
            sheet_height,
            width,
            height,
        )
    finally:
        bpy.data.images.remove(image, do_unlink=True)


def _contact_sheet(style_records, tile_width, tile_height):
    digit_rows = {
        "0": ("111", "101", "101", "101", "111"),
        "1": ("010", "110", "010", "010", "111"),
        "2": ("111", "001", "111", "100", "111"),
        "3": ("111", "001", "111", "001", "111"),
        "4": ("101", "101", "111", "001", "001"),
        "5": ("111", "100", "111", "001", "111"),
        "6": ("111", "100", "111", "101", "111"),
        "7": ("111", "001", "010", "010", "010"),
        "8": ("111", "101", "111", "101", "111"),
        "9": ("111", "101", "111", "001", "111"),
    }
    style_count = len(style_records)
    if style_count <= 6:
        columns = 3
    elif style_count <= 20:
        columns = 4
    else:
        columns = 4
    rows_count = (len(style_records) + columns - 1) // columns
    gap = 18
    width = columns * tile_width + (columns + 1) * gap
    height = rows_count * tile_height + (rows_count + 1) * gap
    result = array("f", [0.0]) * (width * height * 4)

    for y in range(height):
        for x in range(width):
            checker = 0.36 if ((x // 8) + (y // 8)) % 2 == 0 else 0.54
            target = (y * width + x) * 4
            result[target] = checker
            result[target + 1] = checker
            result[target + 2] = checker
            result[target + 3] = 1.0

    for style_index, record in enumerate(style_records):
        column = style_index % columns
        row_from_top = style_index // columns
        origin_x = gap + column * (tile_width + gap)
        origin_y = height - gap - (row_from_top + 1) * tile_height - row_from_top * gap
        pixels = record["pixels"]
        premultiplied = record["alpha_mode"] == "PREMUL"
        for y in range(tile_height):
            for x in range(tile_width):
                source = (y * tile_width + x) * 4
                target = ((origin_y + y) * width + origin_x + x) * 4
                alpha = max(0.0, min(1.0, pixels[source + 3]))
                for channel in range(3):
                    foreground = pixels[source + channel]
                    if premultiplied:
                        result[target + channel] = foreground + result[target + channel] * (1.0 - alpha)
                    else:
                        result[target + channel] = foreground * alpha + result[target + channel] * (1.0 - alpha)
                result[target + 3] = 1.0

        # Number badges match the indexed filenames (__01_, __02_, ...).
        badge_x = origin_x
        badge_y = origin_y + tile_height + 2
        for y in range(14):
            for x in range(20):
                target = ((badge_y + y) * width + badge_x + x) * 4
                result[target] = 0.025
                result[target + 1] = 0.025
                result[target + 2] = 0.025
                result[target + 3] = 1.0
        label = f"{style_index + 1:02d}"
        for digit_index, digit in enumerate(label):
            for row_index, row_bits in enumerate(digit_rows[digit]):
                for column_index, bit in enumerate(row_bits):
                    if bit != "1":
                        continue
                    pixel_x = badge_x + 2 + digit_index * 8 + column_index * 2
                    pixel_y = badge_y + 2 + (4 - row_index) * 2
                    for offset_y in range(2):
                        for offset_x in range(2):
                            target = (
                                (pixel_y + offset_y) * width
                                + pixel_x
                                + offset_x
                            ) * 4
                            result[target] = 1.0
                            result[target + 1] = 1.0
                            result[target + 2] = 1.0
                            result[target + 3] = 1.0
    return result, width, height


def _pack_paths(output, keys, make_contact_sheet):
    base, _extension = os.path.splitext(output)
    paths = {
        key: f"{base}__{index:02d}_{key}.png"
        for index, key in enumerate(keys, start=1)
    }
    contact = f"{base}__00_porownanie.png" if make_contact_sheet else None
    manifest = f"{base}__style_manifest.json"
    return paths, contact, manifest


def _output_path(settings):
    path = bpy.path.abspath(settings.output_path)
    if not path.lower().endswith(".png"):
        path += ".png"
    return os.path.normpath(path)


class TIBIA3X4_PG_Settings(PropertyGroup):
    source_mode: EnumProperty(
        name="Source",
        items=(
            ("COLLECTION", "Collection", "Render the entire selected collection"),
            ("SELECTED", "Selection", "Render selected objects and their children"),
        ),
        default="COLLECTION",
        translation_context=I18N_CONTEXT,
    )
    target_collection: PointerProperty(
        name="Model", type=bpy.types.Collection, translation_context=I18N_CONTEXT
    )
    include_children: BoolProperty(
        name="Include Children", default=True, translation_context=I18N_CONTEXT
    )
    pivot_object: PointerProperty(
        name="Pivot (optional)",
        type=bpy.types.Object,
        description="Rotation pivot; when empty, uses the model center at foot level",
        translation_context=I18N_CONTEXT,
    )

    frame_1: IntProperty(
        name="Frame 1", default=1, min=-1048574, max=1048574,
        translation_context=I18N_CONTEXT,
    )
    frame_2: IntProperty(
        name="Frame 2", default=2, min=-1048574, max=1048574,
        translation_context=I18N_CONTEXT,
    )
    frame_3: IntProperty(
        name="Frame 3", default=3, min=-1048574, max=1048574,
        translation_context=I18N_CONTEXT,
    )
    row_order: EnumProperty(
        name="Rows from Top",
        items=(
            ("S_E_N_W", "S, E, N, W", "South, east, north, west"),
            ("S_W_N_E", "S, W, N, E", "South, west, north, east"),
        ),
        default="S_E_N_W",
        translation_context=I18N_CONTEXT,
    )
    front_axis: EnumProperty(
        name="Model Front",
        items=(
            ("NEG_Y", "-Y", "The model front points along local -Y"),
            ("POS_Y", "+Y", "The model front points along local +Y"),
            ("POS_X", "+X", "The model front points along local +X"),
            ("NEG_X", "-X", "The model front points along local -X"),
        ),
        default="NEG_Y",
        translation_context=I18N_CONTEXT,
    )
    rotation_offset: FloatProperty(
        name="Direction Correction",
        subtype="ANGLE",
        default=0.0,
        soft_min=radians(-180.0),
        soft_max=radians(180.0),
        translation_context=I18N_CONTEXT,
    )

    projection_mode: EnumProperty(
        name="Perspective",
        items=(
            (
                "OBLIQUE",
                "Tibia / lattice from file",
                "Top-down camera and oblique deformation matching the Perspectiva45 file",
            ),
            (
                "ISOMETRIC",
                "45° Ortho Camera",
                "Classic orthographic camera tilted above the model",
            ),
        ),
        default="OBLIQUE",
        translation_context=I18N_CONTEXT,
    )
    shear_x: FloatProperty(
        name="Shear X", default=-0.6, min=-2.0, max=2.0,
        translation_context=I18N_CONTEXT,
    )
    shear_y: FloatProperty(
        name="Shear Y", default=0.6, min=-2.0, max=2.0,
        translation_context=I18N_CONTEXT,
    )
    z_scale: FloatProperty(
        name="Z Compression", default=0.8, min=0.1, max=2.0,
        translation_context=I18N_CONTEXT,
    )
    camera_azimuth: FloatProperty(
        name="Camera Azimuth",
        subtype="ANGLE",
        default=radians(135.0),
        translation_context=I18N_CONTEXT,
    )
    camera_elevation: FloatProperty(
        name="Camera Elevation",
        subtype="ANGLE",
        default=radians(43.3),
        min=radians(5.0),
        max=radians(89.0),
        translation_context=I18N_CONTEXT,
    )

    cell_width: IntProperty(
        name="Width", default=64, min=8, max=512,
        translation_context=I18N_CONTEXT,
    )
    cell_height: IntProperty(
        name="Height", default=64, min=8, max=512,
        translation_context=I18N_CONTEXT,
    )
    padding: IntProperty(
        name="Padding", default=4, min=0, max=512,
        translation_context=I18N_CONTEXT,
    )
    pixel_scale: FloatProperty(
        name="Pixelization Scale",
        description="1.0 renders at full resolution; 0.5 produces 2x2 pixels",
        default=1.0,
        min=0.125,
        max=1.0,
        step=12.5,
        translation_context=I18N_CONTEXT,
    )
    tibia_render_scale: EnumProperty(
        name="TibiaDevs Working Scale",
        description=(
            "Renders each cell at a higher resolution, then downsamples it "
            "using three methods"
        ),
        items=(
            ("4", "4× (faster)", "Base render is 4 times larger"),
            ("8", "8× (more detail)", "Base render is 8 times larger; slower"),
        ),
        default="4",
        translation_context=I18N_CONTEXT,
    )
    tibia_use_outlines: BoolProperty(
        name="Use TibiaDevs Outlines",
        description=(
            "Enables two Freestyle outline sets; when disabled, generates "
            "12 variants completely without an outline"
        ),
        default=True,
        translation_context=I18N_CONTEXT,
    )
    vertical_shift: FloatProperty(
        name="Vertical Shift",
        description="Moves the model inside the cell without changing shared framing",
        default=0.0,
        min=-0.5,
        max=0.5,
        translation_context=I18N_CONTEXT,
    )

    style_mode: EnumProperty(
        name="Output Variants",
        items=(
            (
                "SINGLE",
                "Single Sheet",
                "One standard render using the selected outline settings",
            ),
            (
                "COMPARE",
                "Comparison — 6 Styles",
                "Color, outlined color, white shading, toon, silhouette and alpha",
            ),
            (
                "PIXEL",
                "Pixel-art Styles — 20",
                "Twenty appearance variants: toon, palettes, dithering, clay, ink and readable pixel art preserving model colors",
            ),
            (
                "FULL",
                "Technical Package — 10",
                "The comparison package plus outline, normals, depth and object IDs",
            ),
            (
                "LAB",
                "Full Laboratory — 32",
                "Twenty pixel-art styles plus twelve masks and technical layers",
            ),
            (
                "TIBIA",
                "TibiaDevs Test — 12/24",
                "No outline or two outline methods, three downsampling filters and four sharpening levels",
            ),
        ),
        default="LAB",
        translation_context=I18N_CONTEXT,
    )
    make_contact_sheet: BoolProperty(
        name="Comparison Sheet",
        description="Save an additional PNG with variants arranged side by side",
        default=True,
        translation_context=I18N_CONTEXT,
    )
    clay_color: FloatVectorProperty(
        name="White Style Tint",
        subtype="COLOR",
        default=(0.92, 0.92, 0.92),
        min=0.0,
        max=1.0,
        size=3,
        translation_context=I18N_CONTEXT,
    )
    use_outline: BoolProperty(
        name="Freestyle Outline", default=True,
        translation_context=I18N_CONTEXT,
    )
    outline_thickness: FloatProperty(
        name="Outline Thickness", default=1.0, min=0.25, max=8.0,
        translation_context=I18N_CONTEXT,
    )
    outline_color: FloatVectorProperty(
        name="Outline Color",
        subtype="COLOR",
        default=(0.015, 0.015, 0.015),
        min=0.0,
        max=1.0,
        size=3,
        translation_context=I18N_CONTEXT,
    )
    crisp_alpha: BoolProperty(
        name="Crisp Alpha", default=True, translation_context=I18N_CONTEXT
    )
    alpha_threshold: FloatProperty(
        name="Alpha Threshold", default=0.5, min=0.0, max=1.0,
        translation_context=I18N_CONTEXT,
    )
    copy_scene_lights: BoolProperty(
        name="Use Scene Lights", default=True, translation_context=I18N_CONTEXT
    )

    output_path: StringProperty(
        name="PNG File",
        subtype="FILE_PATH",
        default="//renders/tibia_spritesheet.png",
        translation_context=I18N_CONTEXT,
    )
    overwrite: BoolProperty(
        name="Overwrite Existing File", default=True,
        translation_context=I18N_CONTEXT,
    )


class TIBIA3X4_OT_Setup(Operator):
    bl_idname = "tibia3x4.setup_scene"
    bl_label = "Prepare Model Collection"
    bl_description = "Creates and selects TIBIA_TARGET without changing scene settings"
    bl_translation_context = I18N_CONTEXT
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        scene = context.scene
        settings = scene.tibia3x4_settings
        collection = bpy.data.collections.get("TIBIA_TARGET")
        if collection is None:
            collection = bpy.data.collections.new("TIBIA_TARGET")
            collection["tibia3x4_target"] = True

        def linked_recursive(parent):
            if parent.children.get(collection.name) is collection:
                return True
            return any(linked_recursive(child) for child in parent.children)

        if not linked_recursive(scene.collection):
            scene.collection.children.link(collection)

        settings.source_mode = "COLLECTION"
        settings.target_collection = collection
        self.report(
            {"INFO"},
            _rpt(
                "The TIBIA_TARGET collection is ready. Move the model into it and click Generate."
            ),
        )
        return {"FINISHED"}


class TIBIA3X4_OT_Generate(Operator):
    bl_idname = "tibia3x4.generate"
    bl_label = "Generate 3×4 Spritesheet"
    bl_description = "Renders 12 cells and saves one sheet or a style package"
    bl_translation_context = I18N_CONTEXT

    @classmethod
    def poll(cls, context):
        return context.scene is not None and not bpy.app.is_job_running("RENDER")

    def execute(self, context):
        source_scene = context.scene
        settings = source_scene.tibia3x4_settings
        if (
            settings.style_mode in {"FULL", "LAB"}
            and source_scene.render.engine
            not in {"BLENDER_EEVEE_NEXT", "CYCLES"}
        ):
            self.report(
                {"ERROR"},
                _rpt("Technical layers require the Eevee or Cycles render engine."),
            )
            return {"CANCELLED"}
        output = _output_path(settings)
        output_keys = _style_output_keys(settings)
        style_paths = {}
        contact_path = None
        manifest_path = None
        if settings.style_mode == "SINGLE":
            planned_paths = [output]
        else:
            style_paths, contact_path, manifest_path = _pack_paths(
                output, output_keys, settings.make_contact_sheet
            )
            planned_paths = list(style_paths.values()) + [manifest_path]
            if contact_path is not None:
                planned_paths.append(contact_path)

        if not settings.overwrite:
            existing = next((path for path in planned_paths if os.path.exists(path)), None)
            if existing is not None:
                self.report(
                    {"ERROR"},
                    _rpt(
                        "A file already exists: {filename}. Enable overwriting or change the name."
                    ).format(filename=os.path.basename(existing)),
                )
                return {"CANCELLED"}

        try:
            objects, _renderables = _collect_source_objects(context, settings)
        except TibiaGeneratorError as error:
            self.report({"ERROR"}, _rpt(str(error)))
            return {"CANCELLED"}

        try:
            os.makedirs(os.path.dirname(output) or ".", exist_ok=True)
            temp_directory = tempfile.mkdtemp(prefix="tibia3x4_")
        except OSError as error:
            self.report(
                {"ERROR"},
                _rpt("Could not prepare the output location: {error}").format(
                    error=error
                ),
            )
            return {"CANCELLED"}

        temp_scene = None
        shadow_collection = None
        instancer = None
        shear_parent = None
        camera = None
        camera_data = None
        created_objects = []
        created_data = []
        progress_started = False
        success = False
        existing_linestyle_names = {style.name for style in bpy.data.linestyles}

        original_frame = source_scene.frame_current
        original_subframe = source_scene.frame_subframe
        frames = (settings.frame_1, settings.frame_2, settings.frame_3)
        rows = _direction_rows(settings)

        try:
            shadow_collection = bpy.data.collections.new(ADDON_PREFIX + "Source")
            shadow_collection.instance_offset = (0.0, 0.0, 0.0)
            for obj in objects:
                shadow_collection.objects.link(obj)

            temp_scene = bpy.data.scenes.new(ADDON_PREFIX + "Render")
            temp_scene.render.engine = (
                "BLENDER_EEVEE_NEXT"
                if settings.style_mode == "TIBIA"
                else source_scene.render.engine
            )
            temp_scene.render.film_transparent = True
            temp_scene.render.resolution_percentage = 100
            temp_scene.render.pixel_aspect_x = 1.0
            temp_scene.render.pixel_aspect_y = 1.0
            temp_scene.render.use_border = False
            temp_scene.render.use_crop_to_border = False
            temp_scene.render.use_file_extension = True
            temp_scene.render.image_settings.file_format = "OPEN_EXR"
            temp_scene.render.image_settings.color_mode = "RGBA"
            temp_scene.render.image_settings.color_depth = "32"
            temp_scene.render.image_settings.exr_codec = "ZIP"
            _copy_timing_and_engine(source_scene, temp_scene)

            if settings.style_mode == "TIBIA":
                quality_scale = int(settings.tibia_render_scale)
                render_width = settings.cell_width * quality_scale
                render_height = settings.cell_height * quality_scale
                if max(render_width, render_height) > 2048:
                    raise TibiaGeneratorError(
                        "The TibiaDevs test exceeds 2048 px per working cell. "
                        "Reduce the cell size or select the 4× scale."
                    )
            else:
                render_width = max(
                    1, round(settings.cell_width * settings.pixel_scale)
                )
                render_height = max(
                    1, round(settings.cell_height * settings.pixel_scale)
                )
            temp_scene.render.resolution_x = render_width
            temp_scene.render.resolution_y = render_height
            _copy_color_management(source_scene, temp_scene)
            temp_scene.world = source_scene.world
            if settings.style_mode == "TIBIA":
                temp_scene.render.filter_size = 0.5
                temp_scene.view_settings.view_transform = "Standard"
                temp_scene.view_settings.look = "None"
                temp_scene.view_settings.exposure = 0.0
                temp_scene.view_settings.gamma = 1.0
                temp_scene.view_settings.use_curve_mapping = False
                if hasattr(temp_scene, "eevee") and hasattr(
                    temp_scene.eevee, "taa_render_samples"
                ):
                    temp_scene.eevee.taa_render_samples = 64

            shear_parent = bpy.data.objects.new(ADDON_PREFIX + "Shear", None)
            temp_scene.collection.objects.link(shear_parent)
            created_objects.append(shear_parent)

            instancer = bpy.data.objects.new(ADDON_PREFIX + "Model", None)
            instancer.instance_type = "COLLECTION"
            instancer.instance_collection = shadow_collection
            temp_scene.collection.objects.link(instancer)
            created_objects.append(instancer)
            instancer.parent = shear_parent
            instancer.matrix_parent_inverse = Matrix.Identity(4)
            instancer.matrix_basis = Matrix.Identity(4)

            camera_data = bpy.data.cameras.new(ADDON_PREFIX + "Camera")
            camera = bpy.data.objects.new(ADDON_PREFIX + "Camera", camera_data)
            temp_scene.collection.objects.link(camera)
            created_objects.append(camera)
            created_data.append(camera_data)
            temp_scene.camera = camera

            if settings.style_mode == "TIBIA":
                lights = []
            elif settings.copy_scene_lights:
                lights = [
                    obj
                    for obj in source_scene.objects
                    if obj.type == "LIGHT"
                    and not obj.hide_render
                    and _object_has_renderable_collection_path(
                        source_scene.collection, obj
                    )
                ]
            else:
                lights = []
            if lights:
                for light in lights:
                    _copy_light(light, temp_scene, created_objects, created_data)
            elif settings.style_mode != "TIBIA":
                _create_default_lighting(temp_scene, created_objects, created_data)

            # Identity pass: get a stable pivot and feet plane over all three frames.
            identity_points = _points_for_frames(
                context,
                temp_scene,
                instancer,
                frames,
                (Matrix.Identity(4),),
            )
            raw_min, raw_max = _bounds(identity_points)
            if settings.pivot_object is not None:
                pivot = settings.pivot_object.matrix_world.translation.copy()
                base_z = pivot.z
            else:
                pivot = Vector(
                    (
                        (raw_min.x + raw_max.x) * 0.5,
                        (raw_min.y + raw_max.y) * 0.5,
                        raw_min.z,
                    )
                )
                base_z = raw_min.z

            base_angle = _base_facing_angle(settings)
            direction_matrices = tuple(
                _rotation_about(pivot, base_angle + angle) for _label, angle in rows
            )
            if settings.projection_mode == "OBLIQUE":
                instancer.matrix_parent_inverse = _oblique_matrix(
                    base_z, settings.shear_x, settings.shear_y, settings.z_scale
                )
            else:
                instancer.matrix_parent_inverse = Matrix.Identity(4)

            all_points = _points_for_frames(
                context,
                temp_scene,
                instancer,
                frames,
                direction_matrices,
            )
            world_min, world_max = _bounds(all_points)
            if settings.style_mode == "TIBIA":
                _create_tibiadevs_lighting(
                    temp_scene,
                    world_min,
                    world_max,
                    created_objects,
                    created_data,
                )
            _place_camera(camera, settings, world_min, world_max)
            with _scene_override(context, temp_scene):
                context.view_layer.update()
            _fit_camera(camera, temp_scene, all_points, settings)

            sheet_width = settings.cell_width * 3
            sheet_height = settings.cell_height * 4
            atlas_bytes = sheet_width * sheet_height * 4 * 4
            technical_buffer_count = (
                7 if settings.style_mode == "LAB"
                else 3 if settings.style_mode == "FULL"
                else 0
            )
            line_buffer_count = 1 if settings.style_mode in {"PIXEL", "LAB"} else 0
            base_buffer_count = (
                len(output_keys) + 2 if settings.style_mode == "TIBIA" else 5
            )
            estimated_bytes = atlas_bytes * (
                base_buffer_count + technical_buffer_count + line_buffer_count
            )
            if settings.style_mode == "TIBIA":
                estimated_bytes += render_width * render_height * 4 * 4 * 5
            if settings.make_contact_sheet and settings.style_mode != "SINGLE":
                thumb_width, thumb_height = _contact_thumbnail_size(
                    len(output_keys), sheet_width, sheet_height
                )
                contact_columns = 3 if len(output_keys) <= 6 else 4
                contact_rows = (
                    len(output_keys) + contact_columns - 1
                ) // contact_columns
                contact_gap = 18
                contact_width = (
                    contact_columns * thumb_width
                    + (contact_columns + 1) * contact_gap
                )
                contact_height = (
                    contact_rows * thumb_height
                    + (contact_rows + 1) * contact_gap
                )
                estimated_bytes += (
                    len(output_keys) * thumb_width * thumb_height * 4 * 4
                    + contact_width * contact_height * 4 * 4
                )
            if settings.style_mode in {"FULL", "LAB"}:
                # OIIO temporarily holds one multilayer EXR cell as float channels.
                channel_count = 48 if settings.style_mode == "LAB" else 24
                estimated_bytes += (
                    render_width * render_height * channel_count * 4
                )
            if estimated_bytes > 320 * 1024 * 1024:
                raise TibiaGeneratorError(
                    "This package requires too much memory at the selected size. "
                    "Reduce the cell size or choose a smaller style mode."
                )

            technical_sheets = None
            technical_config = None
            view_layer = temp_scene.view_layers[0]
            if settings.style_mode in {"FULL", "LAB"}:
                extended_passes = settings.style_mode == "LAB"
                view_layer.use_pass_normal = True
                view_layer.use_pass_z = True
                view_layer.use_pass_cryptomatte_object = True
                view_layer.pass_cryptomatte_depth = 6
                view_layer.pass_alpha_threshold = settings.alpha_threshold
                if extended_passes:
                    view_layer.use_pass_diffuse_color = True
                    view_layer.use_pass_diffuse_direct = True
                    view_layer.use_pass_diffuse_indirect = True
                    view_layer.use_pass_ambient_occlusion = True
                    view_layer.use_pass_cryptomatte_material = True
                technical_keys = ["normalne", "glebia", "id_obiektow"]
                if extended_passes:
                    technical_keys.extend(
                        ("albedo", "swiatlo_diffuse", "ao", "id_materialow")
                    )
                technical_sheets = {
                    key: array("f", [0.0]) * (sheet_width * sheet_height * 4)
                    for key in technical_keys
                }
                camera_inverse = camera.matrix_world.inverted_safe()
                depth_values = [
                    -float((camera_inverse @ point).z) for point in all_points
                ]
                technical_config = {
                    "sheets": technical_sheets,
                    "depth_near": min(depth_values),
                    "depth_far": max(depth_values),
                    "world_to_camera": camera.matrix_world.to_3x3().inverted_safe(),
                    "extended": extended_passes,
                }

            progress = [0]
            if settings.style_mode == "TIBIA":
                context.window_manager.progress_begin(0, len(output_keys))
                progress_started = True
                rendered_styles = _render_tibiadevs_sheets(
                    context,
                    temp_scene,
                    instancer,
                    frames,
                    rows,
                    direction_matrices,
                    settings,
                    render_width,
                    render_height,
                    temp_directory,
                    progress,
                )
            else:
                render_specs = _style_render_specs(settings)
                context.window_manager.progress_begin(0, len(render_specs) * 12)
                progress_started = True
                rendered_styles = {}
                for spec in render_specs:
                    view_layer.material_override = spec["material"]
                    _configure_outline(temp_scene, settings, enabled=spec["outline"])
                    pixels, alpha_mode, soft_alpha = _render_style_sheet(
                        context,
                        temp_scene,
                        instancer,
                        frames,
                        rows,
                        direction_matrices,
                        settings,
                        render_width,
                        render_height,
                        temp_directory,
                        spec["key"],
                        progress,
                        technical_config=(
                            technical_config if spec["key"] == "kolor" else None
                        ),
                    )
                    rendered_styles[spec["key"]] = {
                        "pixels": pixels,
                        "alpha_mode": alpha_mode,
                        "soft_alpha": soft_alpha,
                    }
            view_layer.material_override = None

            if settings.style_mode == "SINGLE":
                record = rendered_styles["single"]
                _save_pixels_png(
                    record["pixels"],
                    sheet_width,
                    sheet_height,
                    record["alpha_mode"],
                    output,
                    temp_scene,
                    "Tibia_Spritesheet_3x4",
                )
                success = True
                self.report(
                    {"INFO"},
                    _rpt("Finished: {width}×{height}px — {output}").format(
                        width=sheet_width,
                        height=sheet_height,
                        output=output,
                    ),
                )
            else:
                sources = None
                if settings.style_mode != "TIBIA":
                    beauty = rendered_styles["kolor"]
                    soft_alpha = beauty["soft_alpha"]
                    line_consumers = {
                        "biale_kontur",
                        "toon_3_kontur",
                        "pixel_czytelny",
                        "tusz_1bit",
                        "maska_linii",
                    }
                    line_mask = None
                    if line_consumers.intersection(output_keys):
                        line_mask, _line_mode = _make_render_line_mask(
                            beauty["pixels"],
                            beauty["alpha_mode"],
                            rendered_styles["kolor_kontur"]["pixels"],
                            rendered_styles["kolor_kontur"]["alpha_mode"],
                        )
                    sources = {
                        "kolor": beauty,
                        "kolor_kontur": rendered_styles["kolor_kontur"],
                        "soft_alpha": soft_alpha,
                        "line_mask": line_mask,
                        "technical": technical_sheets,
                    }

                contact_records = []
                thumbnail_width = thumbnail_height = None
                if contact_path is not None:
                    thumbnail_width, thumbnail_height = _contact_thumbnail_size(
                        len(output_keys), sheet_width, sheet_height
                    )
                for index, key in enumerate(output_keys, start=1):
                    if settings.style_mode == "TIBIA":
                        record = rendered_styles[key]
                    else:
                        record = _build_style_record(
                            key, sources, settings, sheet_width, sheet_height
                        )
                    display_label = _localized_style_label(key)
                    record["key"] = key
                    record["label"] = display_label
                    _save_pixels_png(
                        record["pixels"],
                        sheet_width,
                        sheet_height,
                        record["alpha_mode"],
                        style_paths[key],
                        temp_scene,
                        f"Tibia_Style_{index:02d}_{key}",
                        data_output=(
                            key in DATA_STYLE_KEYS
                            and key not in STANDARD_COLOR_STYLE_KEYS
                        ),
                        standard_output=(key in STANDARD_COLOR_STYLE_KEYS),
                    )
                    if contact_path is not None:
                        contact_records.append(
                            _load_saved_contact_thumbnail(
                                style_paths[key],
                                key,
                                display_label,
                                sheet_width,
                                sheet_height,
                                thumbnail_width,
                                thumbnail_height,
                            )
                        )
                    del record

                if contact_path is not None:
                    contact_pixels, contact_width, contact_height = _contact_sheet(
                        contact_records, thumbnail_width, thumbnail_height
                    )
                    _save_pixels_png(
                        contact_pixels,
                        contact_width,
                        contact_height,
                        "STRAIGHT",
                        contact_path,
                        temp_scene,
                        "Tibia_Style_Comparison",
                        data_output=True,
                    )

                manifest = {
                    "generator": "Tibia Spritesheet Generator 3x4",
                    "version": "1.4.0",
                    "manifest_schema_version": 3,
                    "locale": bpy.app.translations.locale,
                    "style_mode": settings.style_mode,
                    "cell_size": [settings.cell_width, settings.cell_height],
                    "sheet_size": [sheet_width, sheet_height],
                    "frames": list(frames),
                    "rows_top_to_bottom": [label for label, _angle in rows],
                    "projection": settings.projection_mode,
                    "crisp_alpha": settings.crisp_alpha,
                    "alpha_threshold": settings.alpha_threshold,
                    "tibiadevs_render_scale": (
                        int(settings.tibia_render_scale)
                        if settings.style_mode == "TIBIA"
                        else None
                    ),
                    "tibiadevs_use_outlines": (
                        bool(settings.tibia_use_outlines)
                        if settings.style_mode == "TIBIA"
                        else None
                    ),
                    "contact_sheet": (
                        os.path.basename(contact_path)
                        if contact_path is not None
                        else None
                    ),
                    "styles": [
                        {
                            "index": index,
                            "key": key,
                            "label": STYLE_LABELS[key],
                            "localized_label": _localized_style_label(key),
                            "category": STYLE_CATEGORIES.get(key, "other"),
                            "file": os.path.basename(style_paths[key]),
                            "tibiadevs": TIBIA_VARIANT_META.get(key),
                        }
                        for index, key in enumerate(output_keys, start=1)
                    ],
                }
                with open(manifest_path, "w", encoding="utf-8") as manifest_file:
                    json.dump(manifest, manifest_file, ensure_ascii=False, indent=2)

                success = True
                extras = _rpt(" + comparison sheet") if contact_path else ""
                self.report(
                    {"INFO"},
                    _rpt("Finished: {count} styles{extras} — {directory}").format(
                        count=len(output_keys),
                        extras=extras,
                        directory=os.path.dirname(output),
                    ),
                )
        except (
            TibiaGeneratorError,
            OSError,
            RuntimeError,
            ValueError,
            TypeError,
            KeyError,
            AttributeError,
            MemoryError,
        ) as error:
            self.report({"ERROR"}, f"Generator: {_rpt(str(error))}")
        finally:
            source_scene.frame_set(original_frame, subframe=original_subframe)
            if progress_started:
                context.window_manager.progress_end()

            if temp_scene is not None:
                bpy.data.scenes.remove(temp_scene, do_unlink=True)
            for obj in reversed(created_objects):
                if obj.name in bpy.data.objects:
                    bpy.data.objects.remove(obj, do_unlink=True)
            for data in reversed(created_data):
                collection = None
                if isinstance(data, bpy.types.Camera):
                    collection = bpy.data.cameras
                elif isinstance(data, bpy.types.Light):
                    collection = bpy.data.lights
                elif isinstance(data, bpy.types.World):
                    collection = bpy.data.worlds
                if collection is not None and data.name in collection and data.users == 0:
                    collection.remove(data, do_unlink=True)
            if shadow_collection is not None and shadow_collection.name in bpy.data.collections:
                bpy.data.collections.remove(shadow_collection, do_unlink=True)
            for style in list(bpy.data.linestyles):
                if (
                    style.name not in existing_linestyle_names
                    and style.users == 0
                ):
                    bpy.data.linestyles.remove(style, do_unlink=True)
            # On Windows the compositor can keep EXR files open until its
            # temporary scene has been released, so remove the directory last.
            shutil.rmtree(temp_directory, ignore_errors=True)

        return {"FINISHED"} if success else {"CANCELLED"}


class TIBIA3X4_PT_Panel(Panel):
    bl_label = "Tibia Spritesheet 3×4"
    bl_idname = "TIBIA3X4_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Tibia 3×4"
    bl_translation_context = I18N_CONTEXT

    def draw(self, context):
        layout = self.layout
        settings = context.scene.tibia3x4_settings

        box = layout.box()
        box.label(text=_iface("Model"), icon="OUTLINER_COLLECTION")
        box.prop(settings, "source_mode", expand=True)
        if settings.source_mode == "COLLECTION":
            box.prop(settings, "target_collection")
        else:
            box.prop(settings, "include_children")
        box.prop(settings, "pivot_object")
        box.operator("tibia3x4.setup_scene", icon="ADD")

        box = layout.box()
        box.label(text=_iface("Animation: 3 Columns"), icon="ACTION")
        row = box.row(align=True)
        row.prop(settings, "frame_1")
        row.prop(settings, "frame_2")
        row.prop(settings, "frame_3")
        box.prop(settings, "row_order")
        box.prop(settings, "front_axis")
        box.prop(settings, "rotation_offset")

        box = layout.box()
        box.label(text=_iface("Perspective"), icon="CAMERA_DATA")
        box.prop(settings, "projection_mode")
        if settings.projection_mode == "OBLIQUE":
            row = box.row(align=True)
            row.prop(settings, "shear_x")
            row.prop(settings, "shear_y")
            box.prop(settings, "z_scale")
        else:
            box.prop(settings, "camera_azimuth")
            box.prop(settings, "camera_elevation")

        box = layout.box()
        box.label(text=_iface("Size and Pixels"), icon="IMAGE_DATA")
        row = box.row(align=True)
        row.prop(settings, "cell_width")
        row.prop(settings, "cell_height")
        box.prop(settings, "padding")
        if settings.style_mode == "TIBIA":
            box.prop(settings, "tibia_render_scale")
            box.label(
                text=_iface("4×/8× render; output stays at the cell size.")
            )
        else:
            box.prop(settings, "pixel_scale")
        box.prop(settings, "vertical_shift")
        box.label(
            text=_iface("Output: {width} × {height} px").format(
                width=settings.cell_width * 3,
                height=settings.cell_height * 4,
            )
        )

        box = layout.box()
        box.label(text=_iface("Output Variants"), icon="RENDERLAYERS")
        box.prop(settings, "style_mode", text=_iface("Mode"))
        if settings.style_mode != "SINGLE":
            box.prop(settings, "make_contact_sheet")
            if settings.style_mode == "TIBIA":
                box.prop(settings, "tibia_use_outlines")
            else:
                box.prop(settings, "clay_color")
            style_count = len(_style_output_keys(settings))
            box.label(
                text=_iface("PNG sheets to save: {count}.").format(
                    count=style_count
                )
            )
            if settings.style_mode == "TIBIA":
                if settings.tibia_use_outlines:
                    box.label(
                        text=_iface(
                            "2 outlines × 3 filters × 4 sharpening levels."
                        )
                    )
                else:
                    box.label(
                        text=_iface(
                            "No outline: 3 filters × 4 sharpening levels."
                        )
                    )
            elif settings.style_mode == "LAB":
                box.label(
                    text=_iface("20 appearances + 12 masks and data layers.")
                )

        box = layout.box()
        box.label(text=_iface("Style"), icon="SHADING_RENDERED")
        if settings.style_mode == "TIBIA":
            box.label(text=_iface("Lights: original SUN + adaptive SPOT"))
            box.label(text=_iface("Colors: Standard, render filter 0.5"))
        else:
            box.prop(settings, "copy_scene_lights")
        if settings.style_mode == "SINGLE":
            box.prop(settings, "use_outline")
        show_outline_controls = (
            settings.use_outline
            if settings.style_mode == "SINGLE"
            else (
                settings.tibia_use_outlines
                if settings.style_mode == "TIBIA"
                else True
            )
        )
        if show_outline_controls:
            row = box.row(align=True)
            row.prop(settings, "outline_thickness")
            row.prop(settings, "outline_color", text="")
            if settings.style_mode == "TIBIA":
                box.label(
                    text=_iface("Thickness is scaled to final output pixels.")
                )
            elif settings.style_mode != "SINGLE":
                box.label(
                    text=_iface("The outline applies to the color + outline variant.")
                )
        elif settings.style_mode == "TIBIA":
            box.label(
                text=_iface(
                    "Freestyle and the black outline are completely disabled."
                )
            )
        box.prop(settings, "crisp_alpha")
        if settings.crisp_alpha:
            box.prop(settings, "alpha_threshold")

        box = layout.box()
        box.label(text=_iface("Save"), icon="FILE_IMAGE")
        box.prop(settings, "output_path")
        box.prop(settings, "overwrite")
        if settings.style_mode == "SINGLE":
            button_text = _iface("Generate 3×4 Spritesheet")
        else:
            style_count = len(_style_output_keys(settings))
            box.label(
                text=_iface("The filename is used as the package prefix."),
                icon="INFO",
            )
            button_text = _iface("Generate Package — {count} Sheets").format(
                count=style_count
            )
        layout.operator(
            "tibia3x4.generate", text=button_text, icon="RENDER_ANIMATION"
        )
        layout.label(
            text=_iface("Rows from top; frames from left."), icon="INFO"
        )


classes = (
    TIBIA3X4_PG_Settings,
    TIBIA3X4_OT_Setup,
    TIBIA3X4_OT_Generate,
    TIBIA3X4_PT_Panel,
)


def register():
    try:
        bpy.app.translations.unregister(__name__)
    except (RuntimeError, ValueError):
        pass
    bpy.app.translations.register(__name__, TRANSLATIONS)

    registered = []
    try:
        for cls in classes:
            bpy.utils.register_class(cls)
            registered.append(cls)
        bpy.types.Scene.tibia3x4_settings = PointerProperty(
            type=TIBIA3X4_PG_Settings
        )
    except Exception:
        for cls in reversed(registered):
            bpy.utils.unregister_class(cls)
        bpy.app.translations.unregister(__name__)
        raise


def unregister():
    if hasattr(bpy.types.Scene, "tibia3x4_settings"):
        del bpy.types.Scene.tibia3x4_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    try:
        bpy.app.translations.unregister(__name__)
    except (RuntimeError, ValueError):
        pass


if __name__ == "__main__":
    register()
